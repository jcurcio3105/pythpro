#!/usr/bin/env python3
"""
Life-science tools innovation evidence pipeline (final_v6 specific-term precision-balanced build).

Free/default sources:
  - patents: USPTO Open Data Portal Patent File Wrapper application search
  - citations: PubMed only by default (no whole-internet citation crawl)
  - biorxiv: bioRxiv metadata API, filtered locally
  - nih_s10: NIH RePORTER S10 instrumentation awards
  - url_scrape: optional, explicit-only URL/link/date scraper

Default date range: 2022-2026 for every module.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import json
import logging
import math
import os
import random
import re
import shutil
import sys
import time
import unicodedata
import urllib.parse
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

try:
    import pandas as pd
    import requests
    import yaml
    from bs4 import BeautifulSoup
    from dotenv import load_dotenv
    from tqdm import tqdm
except ImportError as exc:
    raise SystemExit("Missing dependency. Run: python -m pip install -r requirements.txt") from exc

load_dotenv()

DEFAULT_START_YEAR = 2022
DEFAULT_END_YEAR = 2026
EUROPEPMC_BASE_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest"
PUBMED_BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
OPENALEX_WORKS_URL = "https://api.openalex.org/works"
BIORXIV_BASE_URL = "https://api.biorxiv.org"
NIH_REPORTER_PROJECTS_URL = "https://api.reporter.nih.gov/v2/projects/search"
USPTO_ODP_SEARCH_URL = "https://api.uspto.gov/api/v1/patent/applications/search"

USPTO_ODP_FIELDS = [
    "applicationNumberText",
    "applicationMetaData.inventionTitle",
    "applicationMetaData.filingDate",
    "applicationMetaData.grantDate",
    "applicationMetaData.publicationDate",
    "applicationMetaData.patentNumber",
    "applicationMetaData.firstApplicantName",
    "applicationMetaData.applicationTypeLabelName",
    "applicationMetaData.applicantBag",
    "assignmentBag.assigneeBag",
    "cpcClassificationBag",
]

COMPANY_SUFFIXES = {
    "inc", "incorporated", "corp", "corporation", "co", "company", "ltd", "limited", "llc",
    "gmbh", "ag", "sa", "plc", "bv", "kg", "kgaa", "holdings", "holding", "group",
    "scientific", "technologies", "technology", "instruments", "instrument", "systems", "system",
    "bioscience", "biosciences", "biotech", "biotechnology", "diagnostics", "international",
}

GENERIC_ALIAS_STOPWORDS = {
    "a", "scientific", "technology", "technologies", "instrument", "instruments", "system", "systems",
    "kit", "assay", "reagent", "reagents", "column", "columns", "bio", "group", "research",
}

# Terms in LOW_PRECISION_TEXT_KEYS are too generic to match as standalone text in
# PubMed/bioRxiv. Longer approved phrases such as "Ion Torrent", "Fisher Scientific",
# "Waters Corporation", and "Pall Life Sciences" are still allowed.
LOW_PRECISION_TEXT_KEYS = {
    # Very broad standalone terms that should not be searched/matched in PubMed/bioRxiv text.
    # Full approved phrases such as "Ion Torrent", "Waters Corporation", "Empower CDS",
    # "EnVision Nexus", "JANUS G3", "Jess Simple Western", etc. remain allowed.
    "ion", "ms", "lc", "gc", "xf", "ace", "acd", "era", "ppd", "water",
    "amazon", "andrew", "abby", "milo", "dataanalysis",
    "helix", "janus", "envision", "bioanalyzer", "fragmentanalyzer", "gen5",
    "openlab", "impactii", "biospin", "topspin", "maurice", "jess", "wes",
    "peggysue", "sallysue", "octet", "ique", "simca", "dawn", "empower",
    "unifi", "altr", "dnaprep", "genomeanalyzer", "evolutionone",
}

# Important but ambiguous company/brand names. These are kept in the dictionary, but
# in PubMed/bioRxiv they must appear in a tool/science/vendor context and are flagged
# for review instead of being treated as clean high-confidence matches.
CONTEXT_REQUIRED_TEXT_KEYS = {
    # Core company/brand names retained because they are important but ambiguous.
    # Standalone underspecified product words such as JANUS/EnVision/heliX remain blocked
    # by LOW_PRECISION_TEXT_KEYS; specific model phrases stay active via dictionaries.
    "waters", "fisher", "pall", "leica", "pierce", "nunc", "rainin", "labx",
    "vwr", "hysitron",
}

PUBMED_CONTEXT_TERMS = [
    "instrument", "platform", "analyzer", "analyser", "system", "kit", "assay",
    "reagent", "antibody", "ELISA", "sequencing", "mass spectrometry",
    "chromatography", "LC-MS", "GC-MS", "HPLC", "UPLC", "flow cytometry",
    "spectrometer", "column", "resin", "software", "manufacturer", "supplied",
    "purchased", "obtained", "according to manufacturer"
]

# Short single-token product names that are distinctive enough to allow in PubMed/bioRxiv.
HIGH_PRECISION_SHORT_PRODUCT_KEYS = {
    "iseq", "miseq", "hiseq", "novaseq", "nextseq", "orbitrap", "xevo", "timstof",
    "akta", "qpix", "qtof", "qda", "evos", "krios", "cytof", "dmi8", "xgen",
    "evoq", "mrms", "htrf", "icell", "quantikine", "rnascopes", "rnascope",
    "ique3",
}

LITERATURE_CONTEXT_CUES = {
    "instrument", "platform", "analyzer", "analyser", "system", "kit", "assay", "reagent",
    "antibody", "elisa", "sequenc", "mass spectrom", "spectromet", "chromatograph",
    "flow cytomet", "reader", "scanner", "microscope", "software", "column", "resin",
    "cell culture", "purification", "lc-ms", "lc ms", "gc-ms", "gc ms", "hplc", "uplc",
    "manufacturer", "manufactured", "purchased", "obtained", "supplied", "according to",
    "corporation", "corp", "inc", "incorporated", "company", "ltd", "limited",
    "milford", "waltham", "carlsbad", "pleasanton", "brea", "framingham", "madison",
}

BENCHMARK_KEYWORDS = [
    "benchmark", "benchmarked", "comparison", "comparative", "head-to-head", "head to head",
    "performance evaluation", "validation", "validated", "analytical validation", "outperformed",
    "resolution", "throughput", "accuracy", "precision", "reproducibility", "sensitivity", "specificity",
    "mass accuracy", "limit of detection", "limit of quantification", "read depth", "coverage", "error rate",
]
METHODS_KEYWORDS = [
    "using", "performed on", "performed using", "sequenced on", "sequenced using", "analyzed on",
    "analysed on", "analyzed using", "analysed using", "acquired on", "acquired using", "run on",
    "run using", "instrument", "platform", "mass spectrometer", "spectrometer", "chromatograph",
    "flow cytometer", "reader", "system", "kit", "reagent", "antibody", "column", "assay",
]
REVIEW_KEYWORDS = ["review", "overview", "perspective", "discuss", "recent advances", "we summarize", "we summarise"]

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

class PipelineError(RuntimeError):
    pass


def utc_now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def normalize_space(value: Any) -> str:
    if value is None:
        return ""
    text = html.unescape(str(value))
    text = re.sub(r"\s+", " ", text).strip()
    return text


def ascii_fold(value: Any) -> str:
    text = normalize_space(value)
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")


def normalize_key(value: Any, *, drop_company_suffixes: bool = False) -> str:
    """Case/punctuation-insensitive key.

    ThermoFisher, Thermo Fisher, Thermo-Fisher -> thermofisher.
    """
    text = ascii_fold(value).lower().replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    tokens = [t for t in text.split() if t]
    if drop_company_suffixes:
        tokens = [t for t in tokens if t not in COMPANY_SUFFIXES]
    return "".join(tokens)


def term_tokens(term: Any) -> List[str]:
    return re.findall(r"[A-Za-z]+|[0-9]+", ascii_fold(term))


def flexible_term_regex(term: Any) -> str:
    tokens = term_tokens(term)
    if not tokens:
        return r"a^"
    sep = r"[\s\W_]*"
    body = sep.join(re.escape(tok) for tok in tokens)
    return rf"(?<![A-Za-z0-9]){body}(?![A-Za-z0-9])"


def is_literature_source(source: str) -> bool:
    return normalize_space(source).lower() in {"citations", "literature", "pubmed", "europepmc", "openalex", "biorxiv"}


def has_literature_context_cue(text: Any) -> bool:
    low = ascii_fold(text).lower()
    return any(cue in low for cue in LITERATURE_CONTEXT_CUES)


def key_requires_literature_context(key: str) -> bool:
    return normalize_space(key).lower() in CONTEXT_REQUIRED_TEXT_KEYS


def pubmed_context_clause() -> str:
    parts = []
    for t in PUBMED_CONTEXT_TERMS:
        tt = normalize_space(t).replace(chr(34), " ")
        parts.append(f'"{tt}"[Title/Abstract]')
    return "(" + " OR ".join(parts) + ")"


def pubmed_term_clause(term: Any) -> str:
    term_text = normalize_space(term).replace(chr(34), " ")
    base = f'"{term_text}"[Title/Abstract]'
    key = normalize_key(term_text, drop_company_suffixes=True)
    if key_requires_literature_context(key):
        return f'({base} AND {pubmed_context_clause()})'
    return base


def review_decision_for_mention(m: Dict[str, Any], source: str) -> Dict[str, Any]:
    key = normalize_space(m.get("normalized_match_key"))
    kind = normalize_space(m.get("match_kind"))
    term = normalize_space(m.get("search_term"))
    conf = safe_float(m.get("confidence_score"), 0.0)
    reasons: List[str] = []
    needs = False
    status = "accepted_high_confidence"
    if is_literature_source(source) and key_requires_literature_context(key):
        needs = True
        status = "review_context_required"
        reasons.append("ambiguous_core_term_kept_with_context_requirement")
    if kind == "company_alias" and len(term_tokens(term)) == 1:
        needs = True
        status = "review_single_word_company_alias" if status == "accepted_high_confidence" else status
        reasons.append("single_word_company_alias")
    if kind == "product" and len(term_tokens(term)) == 1 and key not in HIGH_PRECISION_SHORT_PRODUCT_KEYS:
        needs = True
        status = "review_single_word_product" if status == "accepted_high_confidence" else status
        reasons.append("single_word_product_or_brand")
    if conf < 0.72:
        needs = True
        status = "review_low_confidence" if status == "accepted_high_confidence" else status
        reasons.append("low_confidence_score")
    if m.get("mention_type") in {"methods_use", "benchmark_or_validation"} and conf >= 0.78 and not key_requires_literature_context(key):
        needs = False
        status = "accepted_high_confidence"
        reasons.append("strong_methods_or_benchmark_context")
    return {
        "needs_manual_review": bool(needs),
        "review_status": status,
        "review_reason": "; ".join(dict.fromkeys(reasons)),
    }


def term_is_too_loose_for_text(term: Any, *, kind: str, source: str, ambiguous: bool = False, unique_name: bool = True, confidence: float = 0.0, config: Optional[Dict[str, Any]] = None) -> bool:
    """Return True for terms that should not be searched/matched in PubMed/bioRxiv text.

    The patent and NIH modules can still use broader legal/entity terms. This only
    restricts citation/preprint text matching where short/common tokens create false positives.
    """
    if not is_literature_source(source):
        return False
    config = config or {}
    term = normalize_space(term)
    key = normalize_key(term, drop_company_suffixes=(kind == "alias"))
    toks = term_tokens(term)
    if not term or not key:
        return True
    min_chars = int(config.get("minimum_literature_term_chars", 5))
    if key in LOW_PRECISION_TEXT_KEYS:
        return True
    requires_context = key_requires_literature_context(key)
    if len(key) < min_chars and key not in HIGH_PRECISION_SHORT_PRODUCT_KEYS and not requires_context:
        return True
    # Single-token company aliases are retained if distinctive OR if they are a core
    # context-required company/brand term such as Waters/Pall/Fisher/Leica.
    if kind == "alias" and len(toks) == 1:
        if requires_context:
            return False
        if ambiguous or confidence < 0.70:
            return True
        if len(key) < 6 and key not in HIGH_PRECISION_SHORT_PRODUCT_KEYS:
            return True
    # Single-token products are acceptable when distinctive, or when retained as
    # context-required brands that will be flagged for manual review.
    if kind == "product" and len(toks) == 1:
        if requires_context:
            return False
        if ambiguous and confidence < 0.85:
            return True
        if not unique_name and confidence < 0.88:
            return True
    return False


def list_join(values: Iterable[Any], sep: str = "; ") -> str:
    seen: set[str] = set()
    out: List[str] = []
    for v in values:
        text = normalize_space(v)
        if text and text not in seen:
            seen.add(text)
            out.append(text)
    return sep.join(out)


def chunked(seq: Sequence[Any], size: int) -> Iterator[List[Any]]:
    size = max(1, int(size))
    for i in range(0, len(seq), size):
        yield list(seq[i:i + size])


def safe_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(str(value).replace(",", "")))
    except Exception:
        return default


def parse_unlimited_int(value: Any, default: int = 999999999) -> Optional[int]:
    """Return None for unlimited-style config values, otherwise an int."""
    if value is None:
        return default
    text = normalize_space(value).lower()
    if text in {"", "none", "all", "unlimited", "no_limit", "nolimit", "0", "-1"}:
        return None
    try:
        return int(float(text.replace(",", "")))
    except Exception:
        return default


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return default
        return float(str(value).replace(",", ""))
    except Exception:
        return default


def parse_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def year_from_date(value: Any) -> Optional[int]:
    m = re.search(r"(19|20)\d{2}", normalize_space(value))
    return int(m.group(0)) if m else None


def slugify(value: Any, max_len: int = 96) -> str:
    text = normalize_space(value)
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_")
    text = re.sub(r"_+", "_", text)
    return (text or "item")[:max_len]


def sha256_json(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()[:16]


def context_window(text: str, start: int, end: int, window: int = 320) -> str:
    lo = max(0, start - window)
    hi = min(len(text), end + window)
    return normalize_space(text[lo:hi])


def classify_context(ctx: str, section: str = "") -> str:
    c = f"{section} {ctx}".lower()
    if any(k in c for k in BENCHMARK_KEYWORDS):
        return "benchmark_or_validation"
    if any(k in c for k in METHODS_KEYWORDS):
        return "methods_use"
    if any(k in c for k in REVIEW_KEYWORDS):
        return "review_or_background"
    return "generic_mention"


def restore_openalex_abstract(index: Any) -> str:
    if not isinstance(index, dict):
        return ""
    positions: List[Tuple[int, str]] = []
    for word, locs in index.items():
        if isinstance(locs, list):
            for pos in locs:
                try:
                    positions.append((int(pos), str(word)))
                except Exception:
                    pass
    return normalize_space(" ".join(word for _, word in sorted(positions)))


def write_csv(df: pd.DataFrame, path: Path) -> None:
    ensure_dir(path.parent)
    df.to_csv(path, index=False)


def read_csv_if_exists(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def zscore_series(s: pd.Series) -> pd.Series:
    if s.empty:
        return s
    s2 = pd.to_numeric(s, errors="coerce").fillna(0.0)
    if len(s2) <= 1 or float(s2.std(ddof=0)) == 0.0:
        return pd.Series([50.0] * len(s2), index=s.index)
    z = (s2 - s2.mean()) / s2.std(ddof=0)
    return (50 + 15 * z).clip(0, 100)

# ---------------------------------------------------------------------------
# Paths, audit, HTTP
# ---------------------------------------------------------------------------

@dataclass
class RunPaths:
    out_dir: Path
    raw_dir: Path
    processed_dir: Path
    logs_dir: Path
    audit_path: Path
    manifest_path: Path


def setup_run_paths(out_dir: Path, clean_output: bool = True) -> RunPaths:
    if clean_output and out_dir.exists():
        for child in [out_dir / "raw", out_dir / "processed", out_dir / "logs"]:
            if child.exists():
                shutil.rmtree(child)
        manifest = out_dir / "run_manifest.json"
        if manifest.exists():
            manifest.unlink()
    return RunPaths(
        out_dir=ensure_dir(out_dir),
        raw_dir=ensure_dir(out_dir / "raw"),
        processed_dir=ensure_dir(out_dir / "processed"),
        logs_dir=ensure_dir(out_dir / "logs"),
        audit_path=out_dir / "logs" / "audit_queries.csv",
        manifest_path=out_dir / "run_manifest.json",
    )


class AuditLog:
    fields = [
        "timestamp_utc", "source", "company", "module", "query_label", "query_hash",
        "request_method", "request_url", "request_payload_json", "records_returned", "raw_path", "status", "notes",
    ]

    def __init__(self, path: Path) -> None:
        self.path = path
        ensure_dir(path.parent)
        with path.open("w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=self.fields).writeheader()

    def write(self, **kwargs: Any) -> None:
        row = {k: "" for k in self.fields}
        row.update(kwargs)
        row["timestamp_utc"] = row.get("timestamp_utc") or utc_now_iso()
        if not isinstance(row.get("request_payload_json"), str):
            row["request_payload_json"] = json.dumps(row.get("request_payload_json", {}), ensure_ascii=False, default=str)
        with self.path.open("a", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=self.fields).writerow(row)


class RateLimiter:
    def __init__(self, min_interval: float) -> None:
        self.min_interval = float(min_interval)
        self.last = 0.0

    def wait(self) -> None:
        elapsed = time.time() - self.last
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last = time.time()


class HTTPClient:
    def __init__(self, config: Dict[str, Any], logger: logging.Logger) -> None:
        self.config = config
        self.logger = logger
        self.session = requests.Session()
        email = config.get("user_agent_email") or os.environ.get("USER_AGENT_EMAIL") or "innovation-pipeline@example.com"
        self.session.headers.update({
            "User-Agent": f"lifesci-innovation-pipeline/4.4-final-v4 ({email})",
            "Accept": "application/json, text/html, application/xml, text/xml, text/plain;q=0.9, */*;q=0.5",
        })
        r = config.get("rate_limits", {}) or {}
        self.limiters = {
            "uspto_odp": RateLimiter(r.get("uspto_odp_min_interval_seconds", 0.60)),
            "europepmc": RateLimiter(r.get("europepmc_min_interval_seconds", 0.30)),
            "pubmed": RateLimiter(r.get("pubmed_min_interval_seconds", 0.34)),
            "openalex": RateLimiter(r.get("openalex_min_interval_seconds", 0.25)),
            "biorxiv": RateLimiter(r.get("biorxiv_min_interval_seconds", 0.75)),
            "nih": RateLimiter(r.get("nih_min_interval_seconds", 1.05)),
            "scrape": RateLimiter(r.get("scrape_min_interval_seconds", 1.00)),
            "default": RateLimiter(r.get("default_min_interval_seconds", 0.25)),
        }
        self.timeout = int(config.get("http_timeout_seconds", 60))
        self.retries = int(config.get("http_max_retries", 4))

    def request(self, method: str, url: str, *, source: str = "default", params: Optional[Dict[str, Any]] = None,
                json_body: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None,
                expect_json: bool = True, allow_status: Optional[Sequence[int]] = None) -> Any:
        allow = set(allow_status or [])
        limiter = self.limiters.get(source, self.limiters["default"])
        last_exc: Optional[BaseException] = None
        for attempt in range(1, self.retries + 1):
            try:
                limiter.wait()
                resp = self.session.request(method.upper(), url, params=params, json=json_body, headers=headers, timeout=self.timeout)
                if resp.status_code in allow:
                    return {"_status_code": resp.status_code, "_text": resp.text, "_headers": dict(resp.headers)}
                if resp.status_code == 429:
                    delay = safe_float(resp.headers.get("Retry-After"), 20.0)
                    self.logger.warning("Rate limit from %s; sleeping %.1fs", source, delay)
                    time.sleep(min(delay + 0.5, 180.0))
                    continue
                if 500 <= resp.status_code < 600:
                    delay = min(2 ** attempt, 45) + random.random()
                    self.logger.warning("%s %s -> HTTP %s; retry %.1fs", method, url, resp.status_code, delay)
                    time.sleep(delay)
                    continue
                if resp.status_code >= 400:
                    raise PipelineError(f"HTTP {resp.status_code} from {url}: {resp.text[:1000]}")
                if not expect_json:
                    return resp.text
                text = resp.text.strip()
                if "json" in resp.headers.get("content-type", "").lower() or text.startswith("{") or text.startswith("["):
                    return resp.json()
                return text
            except Exception as exc:
                last_exc = exc
                exc_text = str(exc)
                non_retryable = any(f"HTTP {code}" in exc_text for code in (400, 401, 403, 404, 413, 414))
                if attempt >= self.retries or non_retryable:
                    break
                delay = min(2 ** attempt, 45) + random.random()
                self.logger.warning("Request failed attempt %d/%d for %s: %s; retry %.1fs", attempt, self.retries, url, exc, delay)
                time.sleep(delay)
        raise PipelineError(f"Request failed after {self.retries} attempts: {url}; last error={last_exc}")

# ---------------------------------------------------------------------------
# Dictionary and matcher
# ---------------------------------------------------------------------------

class DictionaryManager:
    def __init__(self, base_dir: Path, config: Dict[str, Any], logger: logging.Logger) -> None:
        self.base_dir = base_dir
        self.config = config
        self.logger = logger
        dcfg = config.get("dictionaries", {}) or {}
        self.company_aliases = self._read_csv(dcfg.get("company_aliases", "dictionaries/company_aliases.csv"))
        self.product_terms = self._read_csv(dcfg.get("product_terms", "dictionaries/product_terms.csv"))
        self.negative_terms = self._read_csv(dcfg.get("negative_terms", "dictionaries/negative_terms.csv"), required=False)
        self.url_targets = self._read_csv(dcfg.get("url_targets", "dictionaries/url_targets.csv"), required=False)
        self._product_cache: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
        self._alias_cache: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
        self._prepare()

    def _read_csv(self, relpath: str, required: bool = True) -> pd.DataFrame:
        path = Path(relpath)
        if not path.is_absolute():
            path = self.base_dir / path
        if not path.exists():
            if required:
                raise PipelineError(f"Missing dictionary: {path}")
            return pd.DataFrame()
        return pd.read_csv(path, dtype=str).fillna("")

    def _prepare(self) -> None:
        for df in [self.company_aliases, self.product_terms]:
            if df.empty:
                continue
            if "ticker" in df.columns:
                df["ticker"] = df["ticker"].astype(str).str.upper().str.strip()
            for col in ["include_patents", "include_literature", "include_biorxiv", "include_nih", "include_scrape", "unique_name", "ambiguous"]:
                if col in df.columns:
                    df[col] = df[col].map(lambda x: parse_bool(x, False))
            if "confidence" in df.columns:
                df["confidence"] = df["confidence"].map(lambda x: safe_float(x, 0.8))
        for col in ["include_biorxiv", "include_scrape"]:
            if col not in self.company_aliases.columns and "include_literature" in self.company_aliases.columns:
                self.company_aliases[col] = self.company_aliases["include_literature"]
            if col not in self.product_terms.columns and "include_literature" in self.product_terms.columns:
                self.product_terms[col] = self.product_terms["include_literature"]
        if "normalized_key" not in self.company_aliases.columns:
            self.company_aliases["normalized_key"] = self.company_aliases["alias"].map(lambda x: normalize_key(x, drop_company_suffixes=True))
        if "normalized_key" not in self.product_terms.columns:
            self.product_terms["normalized_key"] = self.product_terms["search_term"].map(normalize_key)

    def _active_year_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """Keep rows whose optional start/end years overlap the run date range.

        Blank years mean unknown/open-ended and are retained. This prevents obvious
        M&A timing errors when dictionary rows include ownership years, without
        excluding legacy rows where timing is not yet curated.
        """
        if df.empty:
            return df
        run_start = safe_int(self.config.get("start_year", DEFAULT_START_YEAR), DEFAULT_START_YEAR)
        run_end = safe_int(self.config.get("end_year", DEFAULT_END_YEAR), DEFAULT_END_YEAR)
        if "start_year" in df.columns:
            starts = df["start_year"].map(lambda x: safe_int(x, 0))
            df = df[(starts == 0) | (starts <= run_end)]
        if "end_year" in df.columns:
            ends = df["end_year"].map(lambda x: safe_int(x, 0))
            df = df[(ends == 0) | (ends >= run_start)]
        return df

    def available_companies(self) -> List[str]:
        return sorted(self.company_aliases["ticker"].dropna().unique().tolist())

    def parent_name(self, ticker: str) -> str:
        rows = self.company_aliases[self.company_aliases["ticker"] == ticker.upper()]
        return normalize_space(rows.iloc[0].get("parent_company")) if not rows.empty else ticker.upper()

    def _include_col(self, source: str) -> str:
        return {
            "patents": "include_patents", "uspto_odp": "include_patents",
            "citations": "include_literature", "literature": "include_literature", "europepmc": "include_literature",
            "pubmed": "include_literature", "openalex": "include_literature",
            "biorxiv": "include_biorxiv", "nih": "include_nih", "nih_s10": "include_nih",
            "url_scrape": "include_scrape", "scrape": "include_scrape",
        }.get(source, "include_literature")

    def aliases(self, ticker: str, source: str) -> pd.DataFrame:
        df = self.company_aliases[self.company_aliases["ticker"] == ticker.upper()].copy()
        df = self._active_year_filter(df)
        col = self._include_col(source)
        if col in df.columns:
            df = df[df[col].map(lambda x: parse_bool(x, False))]
        min_conf = float(self.config.get("min_alias_confidence", 0.50))
        if "confidence" in df.columns:
            df = df[df["confidence"].map(lambda x: safe_float(x, 0.0)) >= min_conf]
        return df

    def products(self, ticker: str, source: str) -> pd.DataFrame:
        df = self.product_terms[self.product_terms["ticker"] == ticker.upper()].copy()
        df = self._active_year_filter(df)
        col = self._include_col(source)
        if col in df.columns:
            df = df[df[col].map(lambda x: parse_bool(x, False))]
        min_conf = float(self.config.get("min_product_confidence", 0.50))
        if "confidence" in df.columns:
            df = df[df["confidence"].map(lambda x: safe_float(x, 0.0)) >= min_conf]
        return df

    def query_terms(self, ticker: str, source: str, include_aliases: bool = True, include_products: bool = True, max_terms: Optional[int] = None) -> List[str]:
        terms: List[str] = []
        if include_products:
            for _, row in self.products(ticker, source).iterrows():
                term = normalize_space(row.get("search_term") or row.get("product_name") or row.get("product_family"))
                if not term:
                    continue
                key = normalize_key(term)
                ambiguous = parse_bool(row.get("ambiguous", False), False)
                unique_name = parse_bool(row.get("unique_name", True), True)
                conf = safe_float(row.get("confidence", 0.0), 0.0)
                if key in GENERIC_ALIAS_STOPWORDS:
                    continue
                if term_is_too_loose_for_text(term, kind="product", source=source, ambiguous=ambiguous, unique_name=unique_name, confidence=conf, config=self.config):
                    continue
                terms.append(term)
        if include_aliases:
            for _, row in self.aliases(ticker, source).iterrows():
                alias = normalize_space(row.get("alias"))
                key = normalize_key(alias, drop_company_suffixes=True)
                conf = safe_float(row.get("confidence", 0.0), 0.0)
                ambiguous = "ambiguous" in normalize_space(row.get("alias_type", "")).lower()
                if not alias or key in GENERIC_ALIAS_STOPWORDS or len(key) <= 3:
                    continue
                if term_is_too_loose_for_text(alias, kind="alias", source=source, ambiguous=ambiguous, unique_name=True, confidence=conf, config=self.config):
                    continue
                terms.append(alias)
                toks = term_tokens(alias)
                if len(toks) >= 2:
                    joined = "".join(toks)
                    if len(joined) > 4:
                        terms.append(joined)
        seen: set[str] = set()
        out: List[str] = []
        for t in sorted(terms, key=lambda x: (-len(normalize_key(x)), normalize_space(x).lower())):
            key = normalize_key(t)
            if key and key not in seen:
                seen.add(key)
                out.append(normalize_space(t))
            if max_terms is not None and max_terms > 0 and len(out) >= max_terms:
                break
        return out

    def _negative_patterns(self) -> Dict[str, List[re.Pattern[str]]]:
        out: Dict[str, List[re.Pattern[str]]] = defaultdict(list)
        if self.negative_terms.empty:
            return out
        for _, row in self.negative_terms.iterrows():
            ticker = normalize_space(row.get("ticker")).upper()
            term = normalize_space(row.get("search_term") or row.get("product_name"))
            patt = normalize_space(row.get("negative_regex") or row.get("negative_term"))
            if ticker and term and patt:
                try:
                    out[f"{ticker}|{normalize_key(term)}"].append(re.compile(patt, re.I))
                except re.error:
                    pass
        return out

    def product_patterns(self, ticker: str, source: str) -> List[Dict[str, Any]]:
        key = (ticker.upper(), source)
        if key in self._product_cache:
            return self._product_cache[key]
        neg = self._negative_patterns()
        rows: List[Dict[str, Any]] = []
        for _, row in self.products(ticker, source).iterrows():
            term = normalize_space(row.get("search_term") or row.get("product_name") or row.get("product_family"))
            if not term:
                continue
            ambiguous = parse_bool(row.get("ambiguous", False), False)
            unique_name = parse_bool(row.get("unique_name", True), True)
            conf = safe_float(row.get("confidence", 0.8), 0.8)
            if term_is_too_loose_for_text(term, kind="product", source=source, ambiguous=ambiguous, unique_name=unique_name, confidence=conf, config=self.config):
                continue
            regex = normalize_space(row.get("regex")) if "regex" in row.index else ""
            try:
                compiled = re.compile(regex or flexible_term_regex(term), re.I)
            except re.error:
                compiled = re.compile(flexible_term_regex(term), re.I)
            rows.append({
                "ticker": ticker.upper(), "parent_company": row.get("parent_company", self.parent_name(ticker)),
                "product_family": row.get("product_family", term), "product_name": row.get("product_name", term),
                "search_term": term, "normalized_key": normalize_key(term), "modality": row.get("modality", ""),
                "segment": row.get("segment", ""), "unique_name": unique_name,
                "ambiguous": ambiguous, "confidence": conf,
                "compiled": compiled, "negative_patterns": neg.get(f"{ticker.upper()}|{normalize_key(term)}", []),
            })
        self._product_cache[key] = rows
        return rows

    def alias_patterns(self, ticker: str, source: str) -> List[Dict[str, Any]]:
        key = (ticker.upper(), source)
        if key in self._alias_cache:
            return self._alias_cache[key]
        rows: List[Dict[str, Any]] = []
        for _, row in self.aliases(ticker, source).iterrows():
            alias = normalize_space(row.get("alias"))
            k = normalize_key(alias, drop_company_suffixes=True)
            conf = safe_float(row.get("confidence", 0.75), 0.75)
            ambiguous = "ambiguous" in normalize_space(row.get("alias_type", "")).lower()
            if not alias or k in GENERIC_ALIAS_STOPWORDS or len(k) <= 3:
                continue
            if term_is_too_loose_for_text(alias, kind="alias", source=source, ambiguous=ambiguous, unique_name=True, confidence=conf, config=self.config):
                continue
            try:
                compiled = re.compile(flexible_term_regex(alias), re.I)
            except re.error:
                continue
            rows.append({
                "ticker": ticker.upper(), "parent_company": row.get("parent_company", self.parent_name(ticker)),
                "alias": alias, "alias_type": row.get("alias_type", ""), "normalized_key": k,
                "confidence": conf, "ambiguous": ambiguous, "compiled": compiled,
            })
        self._alias_cache[key] = rows
        return rows

    def find_mentions(self, ticker: str, text: str, source: str, *, field_name: str = "", section: str = "", include_company_aliases: bool = True, include_products: bool = True) -> List[Dict[str, Any]]:
        text = normalize_space(text)
        if not text:
            return []
        mentions: List[Dict[str, Any]] = []
        if include_products:
            for spec in self.product_patterns(ticker, source):
                for m in spec["compiled"].finditer(text):
                    ctx = context_window(text, m.start(), m.end())
                    if any(p.search(ctx) for p in spec.get("negative_patterns", [])):
                        continue
                    key = spec.get("normalized_key", normalize_key(spec.get("search_term", "")))
                    context_required = key_requires_literature_context(key)
                    if is_literature_source(source) and (spec.get("ambiguous") or context_required) and parse_bool(self.config.get("require_context_for_ambiguous_terms", True), True) and not has_literature_context_cue(ctx):
                        continue
                    mtype = classify_context(ctx, section)
                    conf = float(spec["confidence"]) + (0.05 if field_name in {"title", "abstract"} else 0.0) + (0.05 if mtype in {"methods_use", "benchmark_or_validation"} else 0.0)
                    if spec.get("ambiguous") or context_required:
                        conf -= 0.15
                    row = {
                        "match_kind": "product", "ticker": ticker.upper(), "parent_company": spec["parent_company"],
                        "product_family": spec["product_family"], "product_name": spec["product_name"],
                        "search_term": spec["search_term"], "matched_text": m.group(0), "normalized_match_key": normalize_key(m.group(0)),
                        "modality": spec["modality"], "segment": spec["segment"], "field_name": field_name, "section": section,
                        "mention_type": mtype, "confidence_score": max(0.0, min(1.0, conf)), "context": ctx,
                    }
                    row.update(review_decision_for_mention(row, source))
                    mentions.append(row)
        if include_company_aliases:
            for spec in self.alias_patterns(ticker, source):
                for m in spec["compiled"].finditer(text):
                    ctx = context_window(text, m.start(), m.end())
                    key = spec.get("normalized_key", normalize_key(spec.get("alias", ""), drop_company_suffixes=True))
                    context_required = key_requires_literature_context(key)
                    if is_literature_source(source) and (spec.get("ambiguous") or context_required) and parse_bool(self.config.get("require_context_for_ambiguous_terms", True), True) and not has_literature_context_cue(ctx):
                        continue
                    conf = float(spec["confidence"]) - 0.05 - (0.10 if context_required else 0.0)
                    row = {
                        "match_kind": "company_alias", "ticker": ticker.upper(), "parent_company": spec["parent_company"],
                        "product_family": "", "product_name": "", "search_term": spec["alias"], "matched_text": m.group(0),
                        "normalized_match_key": normalize_key(m.group(0), drop_company_suffixes=True), "modality": "", "segment": "",
                        "field_name": field_name, "section": section, "mention_type": classify_context(ctx, section),
                        "confidence_score": max(0.0, min(1.0, conf)), "context": ctx,
                    }
                    row.update(review_decision_for_mention(row, source))
                    mentions.append(row)
        # Dedupe within same field/context.
        dedup: Dict[Tuple[str, str, str, str], Dict[str, Any]] = {}
        for m in mentions:
            dk = (m["match_kind"], m["normalized_match_key"], field_name, m["context"][:200])
            if dk not in dedup or m["confidence_score"] > dedup[dk]["confidence_score"]:
                dedup[dk] = m
        return list(dedup.values())

# ---------------------------------------------------------------------------
# Source clients
# ---------------------------------------------------------------------------

class USPTOClient:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http = http
        self.config = config
        self.audit = audit
        self.paths = paths
        self.logger = logger
        pcfg = {**(config.get("patentsview", {}) or {}), **(config.get("patents", {}) or {})}
        self.url = pcfg.get("odp_search_url") or USPTO_ODP_SEARCH_URL
        self.api_key = os.environ.get("USPTO_ODP_API_KEY") or os.environ.get("ODP_API_KEY") or os.environ.get("PATENTSVIEW_API_KEY") or normalize_space(pcfg.get("api_key"))
        self.enabled = parse_bool(pcfg.get("enabled", True), True)
        self.page_size = max(1, min(int(pcfg.get("page_size", pcfg.get("per_page", 25))), 100))
        self.min_page_size = max(1, int(pcfg.get("min_page_size", 1)))
        self.max_pages = max(1, int(pcfg.get("max_pages_per_query", 40)))
        self.fields = pcfg.get("odp_fields") or USPTO_ODP_FIELDS
        if isinstance(self.fields, str):
            self.fields = [x.strip() for x in self.fields.split(",") if x.strip()]

    def headers(self) -> Dict[str, str]:
        h = {"Accept": "application/json"}
        if self.api_key:
            h["X-API-KEY"] = self.api_key
        return h

    @staticmethod
    def _safe_term(value: Any) -> str:
        text = normalize_space(value)
        text = re.sub(r"[(){}\[\]^~?:]+", " ", text)
        return normalize_space(text)

    @staticmethod
    def _quote(value: Any) -> str:
        return f'"{normalize_space(value).replace(chr(34), " ")}"'

    @staticmethod
    def _date_clause(start_year: int, end_year: int) -> str:
        return f"applicationMetaData.filingDate:[{start_year}-01-01 TO {end_year}-12-31]"

    @classmethod
    def make_alias_query(cls, aliases: Sequence[str], start_year: int, end_year: int) -> Dict[str, Any]:
        clauses: List[str] = []
        for alias in aliases:
            a = cls._safe_term(alias)
            if not a or len(normalize_key(a)) <= 3:
                continue
            variants = [a]
            toks = term_tokens(a)
            if len(toks) >= 2:
                variants.append("".join(toks))
            for v in variants:
                q = cls._quote(v)
                clauses.extend([
                    f"applicationMetaData.firstApplicantName:{q}",
                    f"applicationMetaData.applicantBag.applicantNameText:{q}",
                    f"assignmentBag.assigneeBag.assigneeNameText:{q}",
                ])
        if not clauses:
            clauses = [cls._quote("life science")]
        q = f"({' OR '.join(clauses)}) AND {cls._date_clause(start_year, end_year)}"
        return {"q": q, "terms": list(aliases), "query_kind": "assignee_alias"}

    def _request_page(self, q: str, offset: int, limit: int, use_fields: bool) -> Any:
        params: Dict[str, Any] = {"q": q, "offset": offset, "limit": limit, "sort": "applicationMetaData.filingDate desc"}
        if use_fields and self.fields:
            params["fields"] = ",".join(self.fields)
        return self.http.request("GET", self.url, source="uspto_odp", params=params, headers=self.headers(), allow_status=[401, 403, 404, 413, 414])

    @staticmethod
    def _extract_records(resp: Any) -> List[Dict[str, Any]]:
        if not isinstance(resp, dict):
            return []
        for key in ["patentFileWrapperDataBag", "results", "data", "applications", "patents"]:
            val = resp.get(key)
            if isinstance(val, list):
                return [x for x in val if isinstance(x, dict)]
            if isinstance(val, dict):
                for subkey in ["patentFileWrapperDataBag", "results", "data", "applications", "patents"]:
                    subv = val.get(subkey)
                    if isinstance(subv, list):
                        return [x for x in subv if isinstance(x, dict)]
        for val in resp.values():
            if isinstance(val, list) and (not val or isinstance(val[0], dict)):
                return [x for x in val if isinstance(x, dict)]
        return []

    def search(self, query: Dict[str, Any], *, company: str, query_label: str, max_records: int) -> List[Dict[str, Any]]:
        qhash = sha256_json({"source": "uspto_odp", "query": query})
        raw_path = self.paths.raw_dir / f"uspto_odp_{company}_{slugify(query_label)}_{qhash}.jsonl"
        records: List[Dict[str, Any]] = []
        status = "ok"
        notes = ""
        if not self.enabled:
            status, notes = "disabled", "USPTO patent module disabled in config."
            self.audit.write(source="uspto_odp", company=company, module="patents", query_label=query_label, query_hash=qhash, request_method="GET", request_url=self.url, request_payload_json=query, records_returned=0, raw_path="", status=status, notes=notes)
            return []
        if not self.api_key:
            status, notes = "skipped_no_api_key", "Set USPTO_ODP_API_KEY in .env to enable patents."
            self.audit.write(source="uspto_odp", company=company, module="patents", query_label=query_label, query_hash=qhash, request_method="GET", request_url=self.url, request_payload_json=query, records_returned=0, raw_path="", status=status, notes=notes)
            return []
        try:
            q = normalize_space(query.get("q"))
            offset = 0
            page = 0
            use_fields = bool(self.fields)
            effective_page_size = self.page_size
            with raw_path.open("w", encoding="utf-8") as f:
                while len(records) < max_records and page < self.max_pages:
                    limit = min(effective_page_size, max_records - len(records))
                    resp = self._request_page(q, offset, limit, use_fields)
                    if isinstance(resp, dict) and resp.get("_status_code"):
                        code = safe_int(resp.get("_status_code"), 0)
                        msg = normalize_space(resp.get("_text", ""))[:600]
                        if code in {401, 403}:
                            status, notes = "skipped_no_access", "USPTO ODP rejected API key/account access."
                            records = []
                            break
                        if code == 404:
                            notes = "No matching USPTO records for this query."
                            break
                        if code == 414:
                            status, notes = "query_too_long", "USPTO ODP returned URL too long; reduce alias_chunk_size."
                            break
                        if code == 413:
                            if limit > self.min_page_size:
                                new_limit = max(self.min_page_size, max(1, limit // 2))
                                self.logger.warning("USPTO payload too large for %s/%s at offset %s; reducing page size %s -> %s", company, query_label, offset, limit, new_limit)
                                notes = (notes + f" Reduced page size {limit}->{new_limit} after HTTP 413.").strip()
                                effective_page_size = new_limit
                                continue
                            notes = (notes + f" USPTO 413 even at page size {limit}: {msg}").strip()
                            break
                        notes = (notes + f" USPTO HTTP {code}: {msg}").strip()
                        break
                    batch = self._extract_records(resp)
                    if not batch:
                        break
                    for rec in batch:
                        rec["_source"] = "uspto_odp"
                        rec["_company_query"] = company
                        rec["_query_hash"] = qhash
                        rec["_query_label"] = query_label
                        f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                        records.append(rec)
                    if len(batch) < limit:
                        break
                    offset += len(batch)
                    page += 1
        except Exception as exc:
            status, notes = "error_skipped", str(exc)
            self.logger.error("USPTO query failed but pipeline will continue: %s", exc)
            records = []
        finally:
            self.audit.write(source="uspto_odp", company=company, module="patents", query_label=query_label, query_hash=qhash, request_method="GET", request_url=self.url, request_payload_json=query, records_returned=len(records), raw_path=str(raw_path) if records else "", status=status, notes=notes)
        return records


class EuropePMCClient:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http, self.config, self.audit, self.paths, self.logger = http, config, audit, paths, logger
        cfg = config.get("europepmc", {}) or {}
        self.base_url = cfg.get("base_url", EUROPEPMC_BASE_URL).rstrip("/")
        self.page_size = min(int(cfg.get("page_size", 100)), 1000)

    @staticmethod
    def make_query(terms: Sequence[str], start_year: int, end_year: int, open_access_only: bool = False) -> str:
        parts = [f'TEXT:"{normalize_space(t).replace(chr(34), " ")}"' for t in terms if normalize_space(t)]
        if not parts:
            raise PipelineError("No terms for Europe PMC query")
        q = f"({' OR '.join(parts)}) AND PUB_YEAR:[{start_year} TO {end_year}]"
        if open_access_only:
            q += " AND OPEN_ACCESS:Y"
        return q

    def search(self, query: str, *, company: str, query_label: str, max_records: int) -> List[Dict[str, Any]]:
        url = f"{self.base_url}/search"
        qhash = sha256_json({"query": query})
        raw_path = self.paths.raw_dir / f"europepmc_{company}_{slugify(query_label)}_{qhash}.jsonl"
        records: List[Dict[str, Any]] = []
        status, notes = "ok", ""
        try:
            cursor = "*"
            with raw_path.open("w", encoding="utf-8") as f:
                while max_records is None or len(records) < max_records:
                    params = {"query": query, "format": "json", "pageSize": min(self.page_size, max_records - len(records)), "cursorMark": cursor, "synonym": "false", "resultType": "core"}
                    resp = self.http.request("GET", url, source="europepmc", params=params)
                    batch = ((resp or {}).get("resultList") or {}).get("result") or []
                    if not isinstance(batch, list) or not batch:
                        break
                    for rec in batch:
                        rec["_source"] = "europepmc"; rec["_company_query"] = company; rec["_query_hash"] = qhash; rec["_query_label"] = query_label
                        f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                        records.append(rec)
                    nxt = (resp or {}).get("nextCursorMark")
                    if not nxt or nxt == cursor:
                        break
                    cursor = nxt
        except Exception as exc:
            status, notes = "error", str(exc)
            self.logger.error("Europe PMC query failed: %s", exc)
            raise
        finally:
            self.audit.write(source="europepmc", company=company, module="citations", query_label=query_label, query_hash=qhash, request_method="GET", request_url=url, request_payload_json={"query": query}, records_returned=len(records), raw_path=str(raw_path), status=status, notes=notes)
        return records


class PubMedClient:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http, self.config, self.audit, self.paths, self.logger = http, config, audit, paths, logger
        cfg = config.get("pubmed", {}) or {}
        self.base_url = cfg.get("base_url", PUBMED_BASE_URL).rstrip("/")
        self.retmax = max(1, min(int(cfg.get("retmax", 200)), 10000))
        self.fetch_batch_size = max(1, min(int(cfg.get("fetch_batch_size", 100)), 200))
        self.tool = cfg.get("tool", "lifesci_innovation_pipeline")
        self.email = cfg.get("email") or config.get("user_agent_email") or os.environ.get("USER_AGENT_EMAIL") or "innovation-pipeline@example.com"
        self.api_key = os.environ.get("NCBI_API_KEY") or normalize_space(cfg.get("api_key"))

    @staticmethod
    def make_query(terms: Sequence[str]) -> str:
        parts = [pubmed_term_clause(t) for t in terms if normalize_space(t)]
        if not parts:
            raise PipelineError("No terms for PubMed query")
        return "(" + " OR ".join(parts) + ")"

    def base_params(self) -> Dict[str, Any]:
        p: Dict[str, Any] = {"tool": self.tool, "email": self.email}
        if self.api_key:
            p["api_key"] = self.api_key
        return p

    def search_ids(self, query: str, start_year: int, end_year: int, max_records: int) -> List[str]:
        ids: List[str] = []
        retstart = 0
        while len(ids) < max_records:
            params = {**self.base_params(), "db": "pubmed", "term": query, "retmode": "json", "retmax": min(self.retmax, max_records - len(ids)), "retstart": retstart, "sort": "pub date", "datetype": "pdat", "mindate": f"{start_year}/01/01", "maxdate": f"{end_year}/12/31"}
            resp = self.http.request("GET", f"{self.base_url}/esearch.fcgi", source="pubmed", params=params)
            batch = (((resp or {}).get("esearchresult") or {}).get("idlist") or [])
            if not isinstance(batch, list) or not batch:
                break
            ids.extend([normalize_space(x) for x in batch if normalize_space(x)])
            if len(batch) < params["retmax"]:
                break
            retstart += len(batch)
        seen: set[str] = set(); out: List[str] = []
        for x in ids:
            if x not in seen:
                seen.add(x); out.append(x)
        return out[:max_records]

    @staticmethod
    def _node_text(node: Optional[ET.Element]) -> str:
        return normalize_space(" ".join(node.itertext())) if node is not None else ""

    @classmethod
    def parse_xml(cls, xml_text: str) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return rows
        for article_node in root.findall(".//PubmedArticle"):
            med = article_node.find("MedlineCitation")
            article = med.find("Article") if med is not None else None
            if med is None or article is None:
                continue
            pmid = normalize_space(med.findtext("PMID"))
            title = cls._node_text(article.find("ArticleTitle"))
            abstract = normalize_space(" ".join(cls._node_text(x) for x in article.findall(".//Abstract/AbstractText")))
            journal = normalize_space(article.findtext("Journal/Title") or article.findtext("Journal/ISOAbbreviation"))
            pubdate_node = article.find("Journal/JournalIssue/PubDate")
            year = normalize_space(pubdate_node.findtext("Year") if pubdate_node is not None else "")
            month = normalize_space(pubdate_node.findtext("Month") if pubdate_node is not None else "")
            day = normalize_space(pubdate_node.findtext("Day") if pubdate_node is not None else "")
            medline_date = normalize_space(pubdate_node.findtext("MedlineDate") if pubdate_node is not None else "")
            publication_date = normalize_space(" ".join([x for x in [year, month, day] if x]) or medline_date)
            doi = ""; pmcid = ""
            for aid in article_node.findall(".//PubmedData/ArticleIdList/ArticleId"):
                id_type = normalize_space(aid.attrib.get("IdType")).lower(); value = normalize_space(aid.text)
                if id_type == "doi" and value: doi = value
                if id_type in {"pmc", "pmcid"} and value: pmcid = value
            authors: List[str] = []
            affiliations: List[str] = []
            for au in article.findall(".//AuthorList/Author"):
                collective = normalize_space(au.findtext("CollectiveName"))
                if collective:
                    authors.append(collective); continue
                nm = normalize_space(f"{normalize_space(au.findtext('ForeName') or au.findtext('Initials'))} {normalize_space(au.findtext('LastName'))}")
                if nm: authors.append(nm)
                for aff in au.findall(".//Affiliation"):
                    txt = cls._node_text(aff)
                    if txt: affiliations.append(txt)
            pub_types = [cls._node_text(x) for x in article.findall(".//PublicationTypeList/PublicationType")]
            rows.append({"source": "pubmed", "pmid": pmid, "title": title, "abstract": abstract, "journal": journal, "publication_date": publication_date, "publication_year": safe_int(year or year_from_date(publication_date), 0), "doi": doi, "pmcid": pmcid, "authors": list_join(authors), "affiliations": list_join(affiliations), "publication_types": list_join(pub_types)})
        return rows

    def search(self, query: str, *, company: str, query_label: str, start_year: int, end_year: int, max_records: int) -> List[Dict[str, Any]]:
        qhash = sha256_json({"source": "pubmed", "query": query, "start_year": start_year, "end_year": end_year})
        raw_path = self.paths.raw_dir / f"pubmed_{company}_{slugify(query_label)}_{qhash}.xml"
        records: List[Dict[str, Any]] = []
        status, notes = "ok", ""
        try:
            pmids = self.search_ids(query, start_year, end_year, max_records)
            if not pmids:
                notes = "No PubMed PMIDs returned."
            with raw_path.open("w", encoding="utf-8") as raw:
                raw.write("<PubMedFetchBatches>\n")
                for batch in chunked(pmids, self.fetch_batch_size):
                    params = {**self.base_params(), "db": "pubmed", "id": ",".join(batch), "retmode": "xml"}
                    xml_text = self.http.request("GET", f"{self.base_url}/efetch.fcgi", source="pubmed", params=params, expect_json=False)
                    raw.write(xml_text + "\n")
                    for rec in self.parse_xml(xml_text):
                        rec["_company_query"] = company; rec["_query_hash"] = qhash; rec["_query_label"] = query_label; rec["_raw_path"] = str(raw_path)
                        records.append(rec)
                raw.write("</PubMedFetchBatches>\n")
        except Exception as exc:
            status, notes = "error", str(exc)
            self.logger.error("PubMed query failed: %s", exc)
            raise
        finally:
            self.audit.write(source="pubmed", company=company, module="citations", query_label=query_label, query_hash=qhash, request_method="GET", request_url=f"{self.base_url}/esearch.fcgi", request_payload_json={"query": query, "start_year": start_year, "end_year": end_year}, records_returned=len(records), raw_path=str(raw_path), status=status, notes=notes)
        return records


class OpenAlexClient:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http, self.config, self.audit, self.paths, self.logger = http, config, audit, paths, logger
        cfg = config.get("openalex", {}) or {}
        self.url = cfg.get("works_url", OPENALEX_WORKS_URL)
        self.per_page = max(1, min(int(cfg.get("per_page", 50)), 200))
        self.max_pages_per_term = max(1, int(cfg.get("max_pages_per_term", 2)))
        self.mailto = cfg.get("mailto") or os.environ.get("OPENALEX_MAILTO") or config.get("user_agent_email") or os.environ.get("USER_AGENT_EMAIL") or ""

    @staticmethod
    def make_query(term: str, start_year: int, end_year: int) -> Dict[str, Any]:
        return {"search": normalize_space(term), "filter": f"from_publication_date:{start_year}-01-01,to_publication_date:{end_year}-12-31", "sort": "publication_date:desc"}

    def search(self, query: Dict[str, Any], *, company: str, query_label: str, max_records: int) -> List[Dict[str, Any]]:
        qhash = sha256_json(query)
        raw_path = self.paths.raw_dir / f"openalex_{company}_{slugify(query_label)}_{qhash}.jsonl"
        records: List[Dict[str, Any]] = []
        status, notes = "ok", ""
        try:
            cursor = "*"; pages = 0
            with raw_path.open("w", encoding="utf-8") as f:
                while len(records) < max_records and pages < self.max_pages_per_term:
                    params = {"search": query.get("search", ""), "filter": query.get("filter", ""), "sort": query.get("sort", "publication_date:desc"), "per-page": min(self.per_page, max_records - len(records)), "cursor": cursor}
                    if self.mailto: params["mailto"] = self.mailto
                    resp = self.http.request("GET", self.url, source="openalex", params=params)
                    batch = (resp or {}).get("results") or []
                    if not isinstance(batch, list) or not batch:
                        break
                    for rec in batch:
                        rec["_source"] = "openalex"; rec["_company_query"] = company; rec["_query_hash"] = qhash; rec["_query_label"] = query_label
                        f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                        records.append(rec)
                    cursor = (((resp or {}).get("meta") or {}).get("next_cursor") or "")
                    if not cursor: break
                    pages += 1
        except Exception as exc:
            status, notes = "error", str(exc)
            self.logger.error("OpenAlex query failed: %s", exc)
            raise
        finally:
            self.audit.write(source="openalex", company=company, module="citations", query_label=query_label, query_hash=qhash, request_method="GET", request_url=self.url, request_payload_json=query, records_returned=len(records), raw_path=str(raw_path), status=status, notes=notes)
        return records


class BioRxivClient:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http, self.config, self.audit, self.paths, self.logger = http, config, audit, paths, logger
        cfg = config.get("biorxiv", {}) or {}
        self.base_url = cfg.get("base_url", BIORXIV_BASE_URL).rstrip("/")
        self.servers = cfg.get("servers", ["biorxiv"])
        self.chunk_days = int(cfg.get("date_chunk_days", 30))

    def iter_date_chunks(self, start_year: int, end_year: int) -> Iterator[Tuple[str, str]]:
        cur = dt.date(start_year, 1, 1); end = dt.date(end_year, 12, 31)
        while cur <= end:
            nxt = min(cur + dt.timedelta(days=self.chunk_days - 1), end)
            yield cur.isoformat(), nxt.isoformat()
            cur = nxt + dt.timedelta(days=1)

    def fetch_interval(self, server: str, start_date: str, end_date: str, max_records: Optional[int]) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        cursor = 0
        qhash = sha256_json({"server": server, "start": start_date, "end": end_date})
        raw_path = self.paths.raw_dir / f"biorxiv_{server}_{start_date}_{end_date}_{qhash}.jsonl"
        status, notes = "ok", ""
        try:
            with raw_path.open("w", encoding="utf-8") as f:
                while max_records is None or len(records) < max_records:
                    url = f"{self.base_url}/details/{server}/{start_date}/{end_date}/{cursor}"
                    resp = self.http.request("GET", url, source="biorxiv")
                    batch = (resp or {}).get("collection") or []
                    if not isinstance(batch, list) or not batch:
                        break
                    for rec in batch:
                        rec["_source"] = "biorxiv"; rec["_server"] = server; rec["_query_hash"] = qhash; rec["_query_label"] = f"{server}_{start_date}_{end_date}"
                        f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                        records.append(rec)
                        if max_records is not None and len(records) >= max_records: break
                    if len(batch) < 100: break
                    cursor += 100
        except Exception as exc:
            status, notes = "error", str(exc)
            self.logger.error("bioRxiv interval failed: %s", exc)
            raise
        finally:
            self.audit.write(source="biorxiv", company="ALL", module="biorxiv", query_label=f"{server}_{start_date}_{end_date}", query_hash=qhash, request_method="GET", request_url=f"{self.base_url}/details/{server}/{start_date}/{end_date}/<cursor>", request_payload_json={"server": server, "start_date": start_date, "end_date": end_date}, records_returned=len(records), raw_path=str(raw_path), status=status, notes=notes)
        return records

    def fetch_all(self, start_year: int, end_year: int, max_records_total: Optional[int]) -> List[Dict[str, Any]]:
        records: List[Dict[str, Any]] = []
        for server in self.servers:
            chunks = list(self.iter_date_chunks(start_year, end_year))
            for start, end in tqdm(chunks, desc=f"bioRxiv {server}"):
                if max_records_total is not None and len(records) >= max_records_total:
                    break
                try:
                    remaining = None if max_records_total is None else max_records_total - len(records)
                    records.extend(self.fetch_interval(server, start, end, remaining))
                except Exception as exc:
                    self.logger.error("bioRxiv chunk skipped %s-%s: %s", start, end, exc)
                    if not parse_bool(self.config.get("continue_on_source_error", True), True): raise
        return records


class NIHReporterClient:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http, self.config, self.audit, self.paths, self.logger = http, config, audit, paths, logger
        cfg = config.get("nih_reporter", config.get("nih_s10", {})) or {}
        self.url = cfg.get("projects_url", NIH_REPORTER_PROJECTS_URL)
        self.limit = min(int(cfg.get("limit", 500)), 500)
        self.activity_codes = cfg.get("activity_codes", ["S10"])

    def make_payload(self, terms: Sequence[str], fiscal_years: Sequence[int], include_fields: Optional[List[str]] = None) -> Dict[str, Any]:
        search_text = " ".join(f'"{normalize_space(t).replace(chr(34), " ")}"' for t in terms if normalize_space(t))
        payload: Dict[str, Any] = {
            "criteria": {"activity_codes": self.activity_codes, "fiscal_years": [int(y) for y in fiscal_years], "exclude_subprojects": True, "advanced_text_search": {"operator": "or", "search_field": "all", "search_text": search_text}},
            "offset": 0, "limit": self.limit, "sort_field": "fiscal_year", "sort_order": "desc",
        }
        if include_fields: payload["include_fields"] = include_fields
        return payload

    def search(self, payload: Dict[str, Any], *, company: str, query_label: str, max_records: int) -> List[Dict[str, Any]]:
        qhash = sha256_json(payload)
        raw_path = self.paths.raw_dir / f"nih_s10_{company}_{slugify(query_label)}_{qhash}.jsonl"
        records: List[Dict[str, Any]] = []
        status, notes = "ok", ""
        try:
            offset = 0
            with raw_path.open("w", encoding="utf-8") as f:
                while max_records is None or len(records) < max_records:
                    req = dict(payload); req["offset"] = offset; req["limit"] = min(int(payload.get("limit", self.limit)), max_records - len(records), 500)
                    resp = self.http.request("POST", self.url, source="nih", json_body=req)
                    batch = (resp or {}).get("results") or (resp or {}).get("data") or []
                    if not isinstance(batch, list) or not batch: break
                    for rec in batch:
                        rec["_source"] = "nih_reporter"; rec["_company_query"] = company; rec["_query_hash"] = qhash; rec["_query_label"] = query_label
                        f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
                        records.append(rec)
                    if len(batch) < req["limit"]: break
                    offset += req["limit"]
                    if offset >= 14999:
                        notes = "Stopped at NIH offset cap. Split query further for exhaustive retrieval."
                        break
        except Exception as exc:
            status, notes = "error", str(exc)
            self.logger.error("NIH RePORTER query failed: %s", exc)
            raise
        finally:
            self.audit.write(source="nih_reporter", company=company, module="nih_s10", query_label=query_label, query_hash=qhash, request_method="POST", request_url=self.url, request_payload_json=payload, records_returned=len(records), raw_path=str(raw_path), status=status, notes=notes)
        return records


class URLScraper:
    def __init__(self, http: HTTPClient, config: Dict[str, Any], audit: AuditLog, paths: RunPaths, logger: logging.Logger) -> None:
        self.http, self.config, self.audit, self.paths, self.logger = http, config, audit, paths, logger

    def scrape(self, url: str, label: str = "", company_filter: str = "") -> Tuple[List[Dict[str, Any]], str]:
        qhash = sha256_json({"url": url})
        raw_path = self.paths.raw_dir / f"url_scrape_{slugify(label or url)}_{qhash}.html"
        rows: List[Dict[str, Any]] = []
        text = ""; status = "ok"; notes = ""
        try:
            html_text = self.http.request("GET", url, source="scrape", expect_json=False)
            raw_path.write_text(html_text, encoding="utf-8", errors="ignore")
            soup = BeautifulSoup(html_text, "html.parser")
            for bad in soup(["script", "style", "noscript", "svg"]): bad.decompose()
            title = normalize_space(soup.title.get_text(" ", strip=True) if soup.title else "")
            text = normalize_space(soup.get_text(" ", strip=True))
            page_date = ""
            for meta_name in [("property", "article:published_time"), ("name", "date"), ("itemprop", "datePublished")]:
                el = soup.find("meta", {meta_name[0]: meta_name[1]})
                if el and el.get("content"):
                    page_date = normalize_space(el.get("content")); break
            for idx, a in enumerate(soup.find_all("a")):
                href = normalize_space(a.get("href")); link_text = normalize_space(a.get_text(" ", strip=True))
                if not href and not link_text: continue
                rows.append({"source_url": url, "page_label": label, "page_title": title, "page_date": page_date, "link_index": idx, "link_text": link_text, "link_url": urllib.parse.urljoin(url, href) if href else "", "context": normalize_space(a.parent.get_text(" ", strip=True)[:1200] if a.parent else link_text), "company_filter": company_filter, "raw_path": str(raw_path)})
        except Exception as exc:
            status, notes = "error", str(exc)
            self.logger.error("URL scrape failed for %s: %s", url, exc)
        finally:
            self.audit.write(source="url_scrape", company=company_filter or "ALL", module="url_scrape", query_label=label or url, query_hash=qhash, request_method="GET", request_url=url, request_payload_json={}, records_returned=len(rows), raw_path=str(raw_path), status=status, notes=notes)
        return rows, text

# ---------------------------------------------------------------------------
# Record processors
# ---------------------------------------------------------------------------

def _bag_values(value: Any, keys: Sequence[str]) -> List[str]:
    out: List[str] = []
    if isinstance(value, dict):
        vals = [value]
    elif isinstance(value, list):
        vals = value
    else:
        vals = []
    for item in vals:
        if isinstance(item, dict):
            for k in keys:
                v = item.get(k)
                if v:
                    out.append(normalize_space(v)); break
        elif item:
            out.append(normalize_space(item))
    seen: set[str] = set(); dedup: List[str] = []
    for x in out:
        k = normalize_key(x, drop_company_suffixes=True)
        if x and k not in seen:
            seen.add(k); dedup.append(x)
    return dedup


def extract_patent_record(rec: Dict[str, Any], dm: DictionaryManager, ticker: str) -> Dict[str, Any]:
    meta = rec.get("applicationMetaData") if isinstance(rec.get("applicationMetaData"), dict) else {}
    app_no = normalize_space(rec.get("applicationNumberText") or meta.get("applicationNumberText"))
    patent_no = normalize_space(meta.get("patentNumber") or rec.get("patentNumber"))
    pub_no = normalize_space(meta.get("earliestPublicationNumber") or rec.get("publicationNumber"))
    title = normalize_space(meta.get("inventionTitle") or rec.get("title"))
    filing = normalize_space(meta.get("filingDate") or rec.get("filingDate"))
    grant = normalize_space(meta.get("grantDate") or rec.get("grantDate"))
    pub_date = normalize_space(meta.get("publicationDate") or meta.get("earliestPublicationDate") or rec.get("publicationDate"))
    applicants: List[str] = []
    if meta.get("firstApplicantName"): applicants.append(normalize_space(meta.get("firstApplicantName")))
    applicants.extend(_bag_values(meta.get("applicantBag"), ["applicantNameText", "name", "organizationName"]))
    assignees = _bag_values((rec.get("assignmentBag") or {}).get("assigneeBag") if isinstance(rec.get("assignmentBag"), dict) else rec.get("assigneeBag"), ["assigneeNameText", "name", "organizationName"])
    cpc_values: List[str] = []
    cpc_bag = rec.get("cpcClassificationBag") or meta.get("cpcClassificationBag")
    for item in cpc_bag if isinstance(cpc_bag, list) else ([] if cpc_bag is None else [cpc_bag]):
        if isinstance(item, dict):
            cpc = normalize_space(item.get("cpcClassificationText") or item.get("classificationSymbol") or item.get("cpcGroup") or item.get("cpcSubclass"))
            if cpc: cpc_values.append(cpc)
    source_url = f"https://patentcenter.uspto.gov/applications/{app_no}" if app_no else ""
    base = {"source": "uspto_odp", "ticker": ticker, "patent_id": patent_no or pub_no or app_no or sha256_json(rec), "application_number": app_no, "patent_number": patent_no, "publication_number": pub_no, "patent_title": title, "filing_date": filing, "grant_date": grant, "publication_date": pub_date, "patent_year": safe_int(year_from_date(filing or grant or pub_date), 0), "first_applicant": applicants[0] if applicants else "", "applicant_names": list_join(applicants), "assignee_names": list_join(assignees), "cpc_symbols": list_join(cpc_values), "source_url": source_url, "query_label": rec.get("_query_label", ""), "query_hash": rec.get("_query_hash", ""), "raw_record_json": json.dumps(rec, ensure_ascii=False, default=str)}
    matched = dm.find_mentions(ticker, title, "patents", field_name="patent_title", include_company_aliases=False, include_products=True)
    base["matched_product_terms"] = list_join(m.get("search_term") for m in matched)
    base["matched_product_count"] = len(matched)
    return base


def europepmc_url(rec: Dict[str, Any]) -> str:
    if normalize_space(rec.get("pmcid")):
        return f"https://europepmc.org/article/PMC/{normalize_space(rec.get('pmcid')).replace('PMC','')}"
    if normalize_space(rec.get("pmid")):
        return f"https://europepmc.org/article/MED/{normalize_space(rec.get('pmid'))}"
    if normalize_space(rec.get("doi")):
        return f"https://doi.org/{normalize_space(rec.get('doi'))}"
    return ""


def openalex_url(rec: Dict[str, Any]) -> str:
    doi = normalize_space(rec.get("doi"))
    if doi:
        return doi if doi.lower().startswith("http") else f"https://doi.org/{doi}"
    return normalize_space(rec.get("id"))


def scholarly_base(rec: Dict[str, Any], source: str, ticker: str) -> Dict[str, Any]:
    if source == "europepmc":
        record_id = normalize_space(rec.get("id") or rec.get("pmid") or rec.get("pmcid") or rec.get("doi") or sha256_json(rec))
        doi = normalize_space(rec.get("doi")); pmid = normalize_space(rec.get("pmid")); pmcid = normalize_space(rec.get("pmcid"))
        return {"source": source, "ticker": ticker, "record_id": record_id, "title": normalize_space(rec.get("title")), "abstract": normalize_space(rec.get("abstractText")), "publication_year": safe_int(rec.get("pubYear") or year_from_date(rec.get("firstPublicationDate")), 0), "publication_date": normalize_space(rec.get("firstPublicationDate") or rec.get("firstIndexDate")), "journal": normalize_space(rec.get("journalTitle")), "doi": doi, "pmid": pmid, "pmcid": pmcid, "cited_by_count": safe_int(rec.get("citedByCount"), 0), "source_url": europepmc_url(rec), "author_string": normalize_space(rec.get("authorString")), "affiliations": "", "publication_types": normalize_space(rec.get("pubType")), "global_record_key": normalize_key(doi or pmid or pmcid or record_id), "query_label": rec.get("_query_label", ""), "query_hash": rec.get("_query_hash", ""), "raw_record_json": json.dumps(rec, ensure_ascii=False, default=str)}
    if source == "pubmed":
        record_id = normalize_space(rec.get("pmid") or rec.get("doi") or sha256_json(rec))
        doi = normalize_space(rec.get("doi")); pmid = normalize_space(rec.get("pmid")); pmcid = normalize_space(rec.get("pmcid"))
        return {"source": source, "ticker": ticker, "record_id": record_id, "title": normalize_space(rec.get("title")), "abstract": normalize_space(rec.get("abstract")), "publication_year": safe_int(rec.get("publication_year") or year_from_date(rec.get("publication_date")), 0), "publication_date": normalize_space(rec.get("publication_date")), "journal": normalize_space(rec.get("journal")), "doi": doi, "pmid": pmid, "pmcid": pmcid, "cited_by_count": 0, "source_url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/" if pmid else (f"https://doi.org/{doi}" if doi else ""), "author_string": normalize_space(rec.get("authors")), "affiliations": normalize_space(rec.get("affiliations")), "publication_types": normalize_space(rec.get("publication_types")), "global_record_key": normalize_key(doi or pmid or pmcid or record_id), "query_label": rec.get("_query_label", ""), "query_hash": rec.get("_query_hash", ""), "raw_record_json": json.dumps(rec, ensure_ascii=False, default=str)}
    # openalex
    ids = rec.get("ids") if isinstance(rec.get("ids"), dict) else {}
    doi = normalize_space(rec.get("doi")); pmid = normalize_space(ids.get("pmid", "")).rsplit("/", 1)[-1]
    primary_location = rec.get("primary_location") if isinstance(rec.get("primary_location"), dict) else {}
    source_obj = primary_location.get("source") if isinstance(primary_location.get("source"), dict) else {}
    authors: List[str] = []
    affiliations: List[str] = []
    for au in (rec.get("authorships") or [])[:40]:
        if not isinstance(au, dict): continue
        a = au.get("author") if isinstance(au.get("author"), dict) else {}
        if normalize_space(a.get("display_name")): authors.append(normalize_space(a.get("display_name")))
        for inst in au.get("institutions", []) or []:
            if isinstance(inst, dict) and normalize_space(inst.get("display_name")): affiliations.append(normalize_space(inst.get("display_name")))
    concepts = [normalize_space(c.get("display_name")) for c in (rec.get("concepts") or []) if isinstance(c, dict)]
    record_id = normalize_space(rec.get("id") or doi or sha256_json(rec))
    return {"source": source, "ticker": ticker, "record_id": record_id, "title": normalize_space(rec.get("title") or rec.get("display_name")), "abstract": restore_openalex_abstract(rec.get("abstract_inverted_index")), "publication_year": safe_int(rec.get("publication_year"), 0), "publication_date": normalize_space(rec.get("publication_date")), "journal": normalize_space(source_obj.get("display_name")), "doi": doi, "pmid": pmid, "pmcid": "", "cited_by_count": safe_int(rec.get("cited_by_count"), 0), "source_url": openalex_url(rec), "author_string": list_join(authors), "affiliations": list_join(affiliations), "publication_types": normalize_space(rec.get("type") or rec.get("raw_type")), "concepts": list_join(concepts), "global_record_key": normalize_key(doi or pmid or record_id), "query_label": rec.get("_query_label", ""), "query_hash": rec.get("_query_hash", ""), "raw_record_json": json.dumps(rec, ensure_ascii=False, default=str)}


def process_scholarly_records(records: List[Dict[str, Any]], dm: DictionaryManager, ticker: str, source: str) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    works: List[Dict[str, Any]] = []
    mentions: List[Dict[str, Any]] = []
    for rec in records:
        base = scholarly_base(rec, source, ticker)
        works.append({**base, "matched_text_available": bool(base.get("title") or base.get("abstract"))})
        for field, text in [("title", base.get("title", "")), ("abstract", base.get("abstract", "")), ("affiliations", base.get("affiliations", "")), ("concepts", base.get("concepts", ""))]:
            for m in dm.find_mentions(ticker, text, "citations", field_name=field, include_company_aliases=True, include_products=True):
                mid = sha256_json({"src": source, "id": base["record_id"], "ticker": ticker, "m": m})
                mentions.append({**base, **m, "mention_id": mid})
    return works, mentions


def biorxiv_url(rec: Dict[str, Any]) -> str:
    doi = normalize_space(rec.get("doi")); version = normalize_space(rec.get("version")); server = normalize_space(rec.get("server") or rec.get("_server") or "biorxiv")
    return f"https://www.{server}.org/content/{doi}{'v' + version if version else ''}" if doi else ""


def process_biorxiv_records(records: List[Dict[str, Any]], dm: DictionaryManager, ticker: str) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    works: List[Dict[str, Any]] = []
    mentions: List[Dict[str, Any]] = []
    for rec in records:
        record_id = normalize_space(rec.get("doi") or sha256_json(rec))
        base = {"source": "biorxiv", "ticker": ticker, "record_id": record_id, "title": normalize_space(rec.get("title")), "abstract": normalize_space(rec.get("abstract")), "publication_year": safe_int(year_from_date(rec.get("date")), 0), "publication_date": normalize_space(rec.get("date")), "journal": "bioRxiv", "doi": normalize_space(rec.get("doi")), "pmid": "", "pmcid": "", "cited_by_count": 0, "category": rec.get("category", ""), "source_url": biorxiv_url(rec), "author_string": normalize_space(rec.get("authors")), "affiliations": normalize_space(rec.get("author_corresponding_institution")), "global_record_key": normalize_key(rec.get("doi") or record_id), "query_label": rec.get("_query_label", ""), "query_hash": rec.get("_query_hash", ""), "raw_record_json": json.dumps(rec, ensure_ascii=False, default=str)}
        text = normalize_space(f"{base['title']} {base['abstract']} {base['author_string']} {base['affiliations']}")
        ms = dm.find_mentions(ticker, text, "biorxiv", field_name="metadata", include_company_aliases=True, include_products=True)
        if ms:
            works.append({**base, "matched_text_available": True})
            for m in ms:
                mentions.append({**base, **m, "mention_id": sha256_json({"src": "biorxiv", "id": record_id, "ticker": ticker, "m": m})})
    return works, mentions


def process_nih_records(records: List[Dict[str, Any]], dm: DictionaryManager, ticker: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for rec in records:
        org = rec.get("organization") if isinstance(rec.get("organization"), dict) else {}
        project_num = normalize_space(rec.get("project_num") or rec.get("core_project_num") or rec.get("appl_id"))
        title = normalize_space(rec.get("project_title") or rec.get("title"))
        abstract = normalize_space(rec.get("abstract_text") or rec.get("phr_text"))
        terms = normalize_space(rec.get("terms"))
        base = {"source": "nih_reporter_s10", "ticker": ticker, "project_num": project_num, "project_title": title, "abstract": abstract, "terms": terms, "fiscal_year": safe_int(rec.get("fiscal_year"), 0), "organization_name": normalize_space(rec.get("organization_name") or rec.get("org_name") or org.get("org_name") or org.get("name")), "organization_city": normalize_space(org.get("org_city") or org.get("city")), "organization_state": normalize_space(org.get("org_state") or org.get("state")), "award_amount": safe_float(rec.get("award_amount") or rec.get("total_cost"), 0.0), "source_url": f"https://reporter.nih.gov/project-details/{normalize_space(rec.get('appl_id'))}" if normalize_space(rec.get("appl_id")) else "", "query_label": rec.get("_query_label", ""), "query_hash": rec.get("_query_hash", ""), "raw_record_json": json.dumps(rec, ensure_ascii=False, default=str)}
        text = normalize_space(f"{title} {abstract} {terms} {base['organization_name']}")
        for m in dm.find_mentions(ticker, text, "nih_s10", field_name="project_text", include_company_aliases=True, include_products=True):
            rows.append({**base, **m, "mention_id": sha256_json({"src": "nih", "project": project_num, "ticker": ticker, "m": m})})
    return rows



def write_review_queue(df: pd.DataFrame, path: Path) -> None:
    if df.empty or "needs_manual_review" not in df.columns:
        write_csv(pd.DataFrame(), path)
        return
    x = df.copy()
    x["needs_manual_review"] = x["needs_manual_review"].map(lambda v: parse_bool(v, False))
    x = x[x["needs_manual_review"]]
    cols = [c for c in [
        "source", "ticker", "record_id", "title", "publication_date", "source_url",
        "match_kind", "search_term", "matched_text", "review_status", "review_reason",
        "confidence_score", "mention_type", "context"
    ] if c in x.columns]
    write_csv(x[cols] if cols else x, path)


def write_edge_case_review_queue(frames: Sequence[pd.DataFrame], path: Path) -> None:
    """Write a consolidated review sheet for agent/human QA.

    This includes explicit manual-review rows plus low-confidence mentions, so the
    audit process catches borderline cases even when the matcher accepted them.
    """
    pieces: List[pd.DataFrame] = []
    for df in frames:
        if df is None or df.empty:
            continue
        x = df.copy()
        if "needs_manual_review" in x.columns:
            needs = x["needs_manual_review"].map(lambda v: parse_bool(v, False))
        else:
            needs = pd.Series([False] * len(x), index=x.index)
        if "confidence_score" in x.columns:
            conf = pd.to_numeric(x["confidence_score"], errors="coerce").fillna(1.0)
            low_conf = conf < 0.82
        else:
            low_conf = pd.Series([False] * len(x), index=x.index)
        y = x[needs | low_conf]
        if not y.empty:
            pieces.append(y)
    if not pieces:
        write_csv(pd.DataFrame(), path)
        return
    out = pd.concat(pieces, ignore_index=True, sort=False)
    cols = [c for c in [
        "source", "ticker", "record_id", "project_num", "title", "project_title",
        "publication_date", "fiscal_year", "source_url", "match_kind", "search_term",
        "matched_text", "review_status", "review_reason", "confidence_score",
        "mention_type", "context", "query_label", "query_hash"
    ] if c in out.columns]
    out = out[cols] if cols else out
    write_csv(out.drop_duplicates(), path)

# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def build_patent_metrics(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["ticker", "patent_count", "unique_patent_count", "matched_product_patents", "patent_signal"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    x = df.copy()
    x["matched_product_count"] = pd.to_numeric(x.get("matched_product_count", 0), errors="coerce").fillna(0)
    out = x.groupby("ticker", dropna=False).agg(patent_count=("patent_id", "count"), unique_patent_count=("patent_id", pd.Series.nunique), matched_product_patents=("matched_product_count", lambda s: int((pd.to_numeric(s, errors="coerce").fillna(0) > 0).sum()))).reset_index()
    out["patent_signal"] = zscore_series(out["unique_patent_count"] + out["matched_product_patents"])
    return out


def build_citation_metrics(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["ticker", "citation_mention_count", "citation_product_mentions", "citation_company_alias_mentions", "citation_unique_records", "citation_benchmark_mentions", "citation_methods_or_probable_use", "citation_weighted_mentions", "citation_signal"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    x = df.copy()
    x["cited_by_count"] = pd.to_numeric(x.get("cited_by_count", 0), errors="coerce").fillna(0)
    x["confidence_score"] = pd.to_numeric(x.get("confidence_score", 0), errors="coerce").fillna(0)
    x["citation_weight"] = x["confidence_score"] * (1 + x["cited_by_count"].map(lambda v: math.log1p(max(0, v))))
    out = x.groupby("ticker", dropna=False).agg(citation_mention_count=("mention_id", "count"), citation_product_mentions=("match_kind", lambda s: int((s == "product").sum())), citation_company_alias_mentions=("match_kind", lambda s: int((s == "company_alias").sum())), citation_unique_records=("global_record_key", pd.Series.nunique), citation_benchmark_mentions=("mention_type", lambda s: int((s == "benchmark_or_validation").sum())), citation_methods_or_probable_use=("mention_type", lambda s: int(s.isin(["methods_use", "probable_use"]).sum())), citation_weighted_mentions=("citation_weight", "sum")).reset_index()
    # Also add per-source mention counts for charting.
    pivot = x.pivot_table(index="ticker", columns="source", values="mention_id", aggfunc="count", fill_value=0).reset_index()
    pivot = pivot.rename(columns={c: f"mentions_{c}" for c in pivot.columns if c != "ticker"})
    out = out.merge(pivot, on="ticker", how="left")
    out["citation_signal"] = zscore_series(out["citation_product_mentions"] + 2 * out["citation_benchmark_mentions"] + out["citation_methods_or_probable_use"] + 0.1 * out["citation_weighted_mentions"])
    return out


def build_biorxiv_metrics(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["ticker", "biorxiv_mention_count", "biorxiv_product_mentions", "biorxiv_unique_preprints", "biorxiv_benchmark_mentions", "biorxiv_signal"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    out = df.groupby("ticker", dropna=False).agg(biorxiv_mention_count=("mention_id", "count"), biorxiv_product_mentions=("match_kind", lambda s: int((s == "product").sum())), biorxiv_unique_preprints=("global_record_key", pd.Series.nunique), biorxiv_benchmark_mentions=("mention_type", lambda s: int((s == "benchmark_or_validation").sum()))).reset_index()
    out["biorxiv_signal"] = zscore_series(out["biorxiv_product_mentions"] + 2 * out["biorxiv_benchmark_mentions"] + out["biorxiv_unique_preprints"])
    return out


def build_nih_metrics(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["ticker", "s10_mention_count", "s10_unique_projects", "s10_unique_institutions", "s10_award_amount", "s10_product_mentions", "nih_s10_signal"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    x = df.copy(); x["award_amount"] = pd.to_numeric(x.get("award_amount", 0), errors="coerce").fillna(0)
    out = x.groupby("ticker", dropna=False).agg(s10_mention_count=("mention_id", "count"), s10_unique_projects=("project_num", pd.Series.nunique), s10_unique_institutions=("organization_name", pd.Series.nunique), s10_award_amount=("award_amount", "sum"), s10_product_mentions=("match_kind", lambda s: int((s == "product").sum()))).reset_index()
    out["nih_s10_signal"] = zscore_series(out["s10_unique_projects"] + out["s10_unique_institutions"] + out["s10_product_mentions"] + 0.000001 * out["s10_award_amount"])
    return out


def build_url_metrics(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["ticker", "url_scrape_mentions", "url_scrape_product_mentions", "url_scrape_unique_urls", "url_scrape_signal"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    out = df.groupby("ticker", dropna=False).agg(url_scrape_mentions=("mention_id", "count"), url_scrape_product_mentions=("match_kind", lambda s: int((s == "product").sum())), url_scrape_unique_urls=("source_url", pd.Series.nunique)).reset_index()
    out["url_scrape_signal"] = zscore_series(out["url_scrape_product_mentions"] + out["url_scrape_unique_urls"])
    return out


def build_index(companies: Sequence[str], patent_metrics: pd.DataFrame, citation_metrics: pd.DataFrame, biorxiv_metrics: pd.DataFrame, nih_metrics: pd.DataFrame, url_metrics: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    base = pd.DataFrame({"ticker": [c.upper() for c in companies]})
    for df in [patent_metrics, citation_metrics, biorxiv_metrics, nih_metrics, url_metrics]:
        if not df.empty and "ticker" in df.columns:
            base = base.merge(df, on="ticker", how="left")
    base = base.fillna(0)
    weights = config.get("index_weights", {}) or {}
    w = {
        "patents": float(weights.get("patents", 0.25)) if not patent_metrics.empty else 0.0,
        "citations": float(weights.get("citations", 0.35)) if not citation_metrics.empty else 0.0,
        "biorxiv": float(weights.get("biorxiv", 0.15)) if not biorxiv_metrics.empty else 0.0,
        "nih_s10": float(weights.get("nih_s10", 0.25)) if not nih_metrics.empty else 0.0,
        "url_scrape": float(weights.get("url_scrape", 0.00)) if not url_metrics.empty else 0.0,
    }
    total = max(sum(w.values()), 1e-9)
    for col in ["patent_signal", "citation_signal", "biorxiv_signal", "nih_s10_signal", "url_scrape_signal"]:
        if col not in base.columns: base[col] = 0.0
    base["innovation_index"] = (w["patents"] * base["patent_signal"] + w["citations"] * base["citation_signal"] + w["biorxiv"] * base["biorxiv_signal"] + w["nih_s10"] * base["nih_s10_signal"] + w["url_scrape"] * base["url_scrape_signal"]) / total
    return base.sort_values("innovation_index", ascending=False)

# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class InnovationPipeline:
    def __init__(self, config: Dict[str, Any], base_dir: Path, out_dir: Path, verbose: bool = False) -> None:
        self.config = config
        self.base_dir = base_dir
        self.clean_output = parse_bool(config.get("clean_output", True), True)
        self.paths = setup_run_paths(out_dir, clean_output=self.clean_output)
        self.logger = logging.getLogger("innovation_pipeline")
        self.logger.handlers.clear(); self.logger.setLevel(logging.DEBUG if verbose else logging.INFO)
        fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        sh = logging.StreamHandler(sys.stdout); sh.setLevel(logging.DEBUG if verbose else logging.INFO); sh.setFormatter(fmt); self.logger.addHandler(sh)
        fh = logging.FileHandler(self.paths.logs_dir / "run.log", encoding="utf-8"); fh.setLevel(logging.DEBUG); fh.setFormatter(fmt); self.logger.addHandler(fh)
        self.audit = AuditLog(self.paths.audit_path)
        self.http = HTTPClient(config, self.logger)
        self.dm = DictionaryManager(base_dir, config, self.logger)
        self.uspto = USPTOClient(self.http, config, self.audit, self.paths, self.logger)
        self.europepmc = EuropePMCClient(self.http, config, self.audit, self.paths, self.logger)
        self.pubmed = PubMedClient(self.http, config, self.audit, self.paths, self.logger)
        self.openalex = OpenAlexClient(self.http, config, self.audit, self.paths, self.logger)
        self.biorxiv = BioRxivClient(self.http, config, self.audit, self.paths, self.logger)
        self.nih = NIHReporterClient(self.http, config, self.audit, self.paths, self.logger)
        self.scraper = URLScraper(self.http, config, self.audit, self.paths, self.logger)
        self.companies = [c.upper() for c in (config.get("companies") or self.dm.available_companies())]
        self.modules = [normalize_space(m).lower() for m in (config.get("modules") or ["patents", "citations", "biorxiv", "nih_s10"])]
        self.start_year = int(config.get("start_year", DEFAULT_START_YEAR))
        self.end_year = int(config.get("end_year", DEFAULT_END_YEAR))
        self.max_records = int(config.get("max_records_per_query", 500))
        self.dry_run = parse_bool(config.get("dry_run", False), False)
        self.continue_on_source_error = parse_bool(config.get("continue_on_source_error", True), True)

    def write_manifest(self, status: str) -> None:
        self.paths.manifest_path.write_text(json.dumps({"status": status, "timestamp_utc": utc_now_iso(), "companies": self.companies, "modules": self.modules, "start_year": self.start_year, "end_year": self.end_year, "config": self.config}, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    def citation_sources(self) -> List[str]:
        sources = self.config.get("citation_sources") or (self.config.get("citations", {}) or {}).get("sources") or ["pubmed"]
        if isinstance(sources, str): sources = [s.strip() for s in sources.split(",") if s.strip()]
        return [s.lower() for s in sources if s.lower() in {"europepmc", "pubmed", "openalex"}]

    def dry_run_plan(self) -> None:
        rows: List[Dict[str, Any]] = []
        fiscal_years = list(range(self.start_year, self.end_year + 1))
        if "patents" in self.modules:
            alias_chunk = int((self.config.get("patents", {}) or self.config.get("patentsview", {}) or {}).get("alias_chunk_size", 2))
            for ticker in self.companies:
                aliases = self.dm.query_terms(
                    ticker, "patents", include_aliases=True, include_products=False,
                    max_terms=parse_unlimited_int((self.config.get("patents", {}) or {}).get("max_alias_terms_per_company", "all"), None),
                )
                for i, chunk in enumerate(chunked(aliases, alias_chunk), 1):
                    rows.append({"module": "patents", "source": "uspto_odp", "ticker": ticker, "query_label": f"assignee_alias_{i:02d}", "payload": json.dumps(self.uspto.make_alias_query(chunk, self.start_year, self.end_year), ensure_ascii=False)})
        if "citations" in self.modules:
            max_terms = parse_unlimited_int((self.config.get("citations", {}) or {}).get("max_terms_per_company", "all"), None)
            for ticker in self.companies:
                terms = self.dm.query_terms(ticker, "citations", include_aliases=True, include_products=True, max_terms=max_terms)
                for src in self.citation_sources():
                    if src == "europepmc":
                        for i, chunk in enumerate(chunked(terms, int((self.config.get("europepmc", {}) or {}).get("term_chunk_size", 10))), 1):
                            rows.append({"module": "citations", "source": src, "ticker": ticker, "query_label": f"europepmc_terms_{i:02d}", "payload": self.europepmc.make_query(chunk, self.start_year, self.end_year)})
                    elif src == "pubmed":
                        for i, chunk in enumerate(chunked(terms, int((self.config.get("pubmed", {}) or {}).get("term_chunk_size", 10))), 1):
                            rows.append({"module": "citations", "source": src, "ticker": ticker, "query_label": f"pubmed_terms_{i:02d}", "payload": self.pubmed.make_query(chunk) + f"; pdat {self.start_year}-{self.end_year}"})
                    elif src == "openalex":
                        for i, term in enumerate(terms[:int((self.config.get("openalex", {}) or {}).get("max_terms_per_company", 40))], 1):
                            rows.append({"module": "citations", "source": src, "ticker": ticker, "query_label": f"openalex_{i:03d}", "payload": json.dumps(self.openalex.make_query(term, self.start_year, self.end_year), ensure_ascii=False)})
        if "biorxiv" in self.modules:
            for server in self.biorxiv.servers:
                for start, end in self.biorxiv.iter_date_chunks(self.start_year, self.end_year):
                    rows.append({"module": "biorxiv", "source": "biorxiv", "ticker": "ALL", "query_label": f"{server}_{start}_{end}", "payload": f"{self.biorxiv.base_url}/details/{server}/{start}/{end}/0"})
        if "nih_s10" in self.modules or "nih" in self.modules:
            for ticker in self.companies:
                terms = self.dm.query_terms(ticker, "nih_s10", include_aliases=True, include_products=True, max_terms=parse_unlimited_int((self.config.get("nih_s10", {}) or {}).get("max_terms_per_company", "all"), None))
                for ychunk in chunked(fiscal_years, int((self.config.get("nih_s10", {}) or {}).get("year_chunk_size", 5))):
                    for i, tchunk in enumerate(chunked(terms, int((self.config.get("nih_s10", {}) or {}).get("term_chunk_size", 14))), 1):
                        rows.append({"module": "nih_s10", "source": "nih_reporter", "ticker": ticker, "query_label": f"y{ychunk[0]}_{ychunk[-1]}_{i:02d}", "payload": json.dumps(self.nih.make_payload(tchunk, ychunk), ensure_ascii=False)})
        if "url_scrape" in self.modules:
            for target in self.iter_url_targets():
                rows.append({"module": "url_scrape", "source": "url", "ticker": target.get("ticker", ""), "query_label": target.get("label", ""), "payload": target.get("url", "")})
        df = pd.DataFrame(rows)
        write_csv(df, self.paths.processed_dir / "dry_run_query_plan.csv")
        self.logger.info("Dry run wrote %d planned queries", len(df))

    def run_patents(self) -> pd.DataFrame:
        if "patents" not in self.modules: return pd.DataFrame()
        all_records: List[Dict[str, Any]] = []
        alias_chunk = int((self.config.get("patents", {}) or self.config.get("patentsview", {}) or {}).get("alias_chunk_size", 2))
        max_terms = parse_unlimited_int((self.config.get("patents", {}) or {}).get("max_alias_terms_per_company", "all"), None)
        for ticker in tqdm(self.companies, desc="USPTO ODP patents"):
            aliases = self.dm.query_terms(ticker, "patents", include_aliases=True, include_products=False, max_terms=max_terms)
            records: List[Dict[str, Any]] = []
            for i, chunk in enumerate(chunked(aliases, alias_chunk), 1):
                q = self.uspto.make_alias_query(chunk, self.start_year, self.end_year)
                records.extend(self.uspto.search(q, company=ticker, query_label=f"assignee_alias_{i:02d}", max_records=self.max_records))
            all_records.extend(extract_patent_record(r, self.dm, ticker) for r in records)
        df = pd.DataFrame(all_records)
        if not df.empty:
            df = df.drop_duplicates(subset=["ticker", "patent_id"], keep="first")
        write_csv(df, self.paths.processed_dir / "patent_records_free.csv")
        write_csv(build_patent_metrics(df), self.paths.processed_dir / "patent_metrics_by_company.csv")
        self.logger.info("Wrote patent records: %d", len(df))
        return df

    def run_citations(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        if "citations" not in self.modules: return pd.DataFrame(), pd.DataFrame()
        work_rows: List[Dict[str, Any]] = []
        mention_rows: List[Dict[str, Any]] = []
        max_terms = parse_unlimited_int((self.config.get("citations", {}) or {}).get("max_terms_per_company", "all"), None)
        for ticker in tqdm(self.companies, desc="Citation databases"):
            terms = self.dm.query_terms(ticker, "citations", include_aliases=True, include_products=True, max_terms=max_terms)
            for src in self.citation_sources():
                records: List[Dict[str, Any]] = []
                if src == "europepmc":
                    tcs = int((self.config.get("europepmc", {}) or {}).get("term_chunk_size", 10))
                    for i, chunk in enumerate(chunked(terms, tcs), 1):
                        try:
                            records.extend(self.europepmc.search(self.europepmc.make_query(chunk, self.start_year, self.end_year), company=ticker, query_label=f"europepmc_terms_{i:02d}", max_records=self.max_records))
                        except Exception as exc:
                            self.logger.error("Europe PMC skipped for %s chunk %s: %s", ticker, i, exc)
                            if not self.continue_on_source_error: raise
                elif src == "pubmed":
                    tcs = int((self.config.get("pubmed", {}) or {}).get("term_chunk_size", 10))
                    for i, chunk in enumerate(chunked(terms, tcs), 1):
                        try:
                            records.extend(self.pubmed.search(self.pubmed.make_query(chunk), company=ticker, query_label=f"pubmed_terms_{i:02d}", start_year=self.start_year, end_year=self.end_year, max_records=self.max_records))
                        except Exception as exc:
                            self.logger.error("PubMed skipped for %s chunk %s: %s", ticker, i, exc)
                            if not self.continue_on_source_error: raise
                elif src == "openalex":
                    max_oa_terms = int((self.config.get("openalex", {}) or {}).get("max_terms_per_company", 40))
                    max_per_term = int((self.config.get("openalex", {}) or {}).get("max_records_per_term", 100))
                    for i, term in enumerate(terms[:max_oa_terms], 1):
                        try:
                            records.extend(self.openalex.search(self.openalex.make_query(term, self.start_year, self.end_year), company=ticker, query_label=f"openalex_{i:03d}_{slugify(term, 32)}", max_records=min(self.max_records, max_per_term)))
                        except Exception as exc:
                            self.logger.error("OpenAlex skipped for %s term %s: %s", ticker, term, exc)
                            if not self.continue_on_source_error: raise
                works, mentions = process_scholarly_records(records, self.dm, ticker, src)
                work_rows.extend(works); mention_rows.extend(mentions)
        works_df = pd.DataFrame(work_rows); mentions_df = pd.DataFrame(mention_rows)
        if not works_df.empty:
            works_df = works_df.drop_duplicates(subset=["source", "ticker", "record_id"], keep="first")
        if not mentions_df.empty:
            dedupe_cols = [c for c in ["ticker", "global_record_key", "normalized_match_key", "field_name", "mention_type"] if c in mentions_df.columns]
            mentions_df = mentions_df.sort_values(["source", "confidence_score"], ascending=[True, False]).drop_duplicates(subset=dedupe_cols, keep="first")
        write_csv(works_df, self.paths.processed_dir / "citation_records.csv")
        write_csv(mentions_df, self.paths.processed_dir / "citation_mentions.csv")
        write_review_queue(mentions_df, self.paths.processed_dir / "citation_review_queue.csv")
        metrics = build_citation_metrics(mentions_df)
        write_csv(metrics, self.paths.processed_dir / "citation_metrics_by_company.csv")
        # Compatibility outputs for previous workbooks/scripts.
        write_csv(works_df, self.paths.processed_dir / "literature_records.csv")
        write_csv(mentions_df, self.paths.processed_dir / "literature_mentions.csv")
        self.logger.info("Wrote citation records=%d mentions=%d", len(works_df), len(mentions_df))
        return works_df, mentions_df

    def run_biorxiv(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        if "biorxiv" not in self.modules: return pd.DataFrame(), pd.DataFrame()
        raw_max_total = (self.config.get("biorxiv", {}) or {}).get("max_records_total", max(5000, self.max_records * 10))
        if raw_max_total is None or str(raw_max_total).strip().lower() in {"all", "none", "unlimited", "no_limit", ""}:
            max_total = None
        else:
            max_total = int(raw_max_total)
        records = self.biorxiv.fetch_all(self.start_year, self.end_year, max_total)
        write_csv(pd.DataFrame(records), self.paths.processed_dir / "biorxiv_raw_records.csv")
        works: List[Dict[str, Any]] = []; mentions: List[Dict[str, Any]] = []
        for ticker in tqdm(self.companies, desc="bioRxiv matching"):
            w, m = process_biorxiv_records(records, self.dm, ticker); works.extend(w); mentions.extend(m)
        works_df = pd.DataFrame(works); mentions_df = pd.DataFrame(mentions)
        if not works_df.empty: works_df = works_df.drop_duplicates(subset=["ticker", "record_id"], keep="first")
        if not mentions_df.empty: mentions_df = mentions_df.drop_duplicates(subset=["ticker", "mention_id"], keep="first")
        write_csv(works_df, self.paths.processed_dir / "biorxiv_records.csv")
        write_csv(mentions_df, self.paths.processed_dir / "biorxiv_mentions.csv")
        write_review_queue(mentions_df, self.paths.processed_dir / "biorxiv_review_queue.csv")
        write_csv(build_biorxiv_metrics(mentions_df), self.paths.processed_dir / "biorxiv_metrics_by_company.csv")
        self.logger.info("Wrote bioRxiv matched records=%d mentions=%d", len(works_df), len(mentions_df))
        return works_df, mentions_df

    def run_nih_s10(self) -> pd.DataFrame:
        if "nih_s10" not in self.modules and "nih" not in self.modules: return pd.DataFrame()
        rows: List[Dict[str, Any]] = []
        fiscal_years = list(range(self.start_year, self.end_year + 1))
        cfg = self.config.get("nih_s10", self.config.get("nih_reporter", {})) or {}
        term_chunk = int(cfg.get("term_chunk_size", 14)); year_chunk = int(cfg.get("year_chunk_size", 5)); max_terms = parse_unlimited_int(cfg.get("max_terms_per_company", "all"), None)
        for ticker in tqdm(self.companies, desc="NIH S10"):
            terms = self.dm.query_terms(ticker, "nih_s10", include_aliases=True, include_products=True, max_terms=max_terms)
            records: List[Dict[str, Any]] = []
            for ychunk in chunked(fiscal_years, year_chunk):
                for i, tchunk in enumerate(chunked(terms, term_chunk), 1):
                    payload = self.nih.make_payload(tchunk, ychunk, include_fields=cfg.get("include_fields"))
                    try:
                        records.extend(self.nih.search(payload, company=ticker, query_label=f"y{ychunk[0]}_{ychunk[-1]}_terms_{i:02d}", max_records=self.max_records))
                    except Exception as exc:
                        self.logger.error("NIH S10 skipped for %s chunk %s: %s", ticker, i, exc)
                        if not self.continue_on_source_error: raise
            rows.extend(process_nih_records(records, self.dm, ticker))
        df = pd.DataFrame(rows)
        if not df.empty: df = df.drop_duplicates(subset=["ticker", "mention_id"], keep="first")
        write_csv(df, self.paths.processed_dir / "nih_s10_award_mentions.csv")
        write_review_queue(df, self.paths.processed_dir / "nih_s10_review_queue.csv")
        write_csv(build_nih_metrics(df), self.paths.processed_dir / "nih_s10_metrics_by_company.csv")
        self.logger.info("Wrote NIH S10 mentions=%d", len(df))
        return df

    def iter_url_targets(self) -> List[Dict[str, str]]:
        targets: List[Dict[str, str]] = []
        for item in (self.config.get("url_scrape", {}) or {}).get("urls", []) or []:
            if isinstance(item, str): targets.append({"url": item, "label": slugify(item), "ticker": ""})
            elif isinstance(item, dict): targets.append({"url": normalize_space(item.get("url")), "label": normalize_space(item.get("label")), "ticker": normalize_space(item.get("ticker")).upper()})
        if not self.dm.url_targets.empty:
            for _, row in self.dm.url_targets.iterrows():
                url = normalize_space(row.get("url"))
                if url: targets.append({"url": url, "label": normalize_space(row.get("label")), "ticker": normalize_space(row.get("ticker")).upper()})
        seen: set[str] = set(); out: List[Dict[str, str]] = []
        for t in targets:
            if t.get("url") and t["url"] not in seen:
                seen.add(t["url"]); out.append(t)
        return out

    def run_url_scrape(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        if "url_scrape" not in self.modules: return pd.DataFrame(), pd.DataFrame()
        links: List[Dict[str, Any]] = []; mentions: List[Dict[str, Any]] = []
        for target in tqdm(self.iter_url_targets(), desc="URL scrape"):
            rows, page_text = self.scraper.scrape(target["url"], label=target.get("label", ""), company_filter=target.get("ticker", ""))
            links.extend(rows)
            tickers = [target["ticker"]] if target.get("ticker") else self.companies
            for ticker in tickers:
                for m in self.dm.find_mentions(ticker, page_text, "url_scrape", field_name="page_text", include_company_aliases=True, include_products=True):
                    mentions.append({"source": "url_scrape", "ticker": ticker, "source_url": target["url"], "page_label": target.get("label", ""), "record_id": target["url"], **m, "mention_id": sha256_json({"url": target["url"], "ticker": ticker, "m": m})})
        links_df = pd.DataFrame(links); mentions_df = pd.DataFrame(mentions)
        write_csv(links_df, self.paths.processed_dir / "url_scrape_links.csv")
        write_csv(mentions_df, self.paths.processed_dir / "url_scrape_mentions.csv")
        write_csv(build_url_metrics(mentions_df), self.paths.processed_dir / "url_scrape_metrics_by_company.csv")
        self.logger.info("Wrote URL scrape links=%d mentions=%d", len(links_df), len(mentions_df))
        return links_df, mentions_df

    def build_outputs(self) -> pd.DataFrame:
        p = self.paths.processed_dir
        patent_records = read_csv_if_exists(p / "patent_records_free.csv") if "patents" in self.modules else pd.DataFrame()
        citation_mentions = read_csv_if_exists(p / "citation_mentions.csv") if "citations" in self.modules else pd.DataFrame()
        biorxiv_mentions = read_csv_if_exists(p / "biorxiv_mentions.csv") if "biorxiv" in self.modules else pd.DataFrame()
        nih_mentions = read_csv_if_exists(p / "nih_s10_award_mentions.csv") if ("nih_s10" in self.modules or "nih" in self.modules) else pd.DataFrame()
        url_mentions = read_csv_if_exists(p / "url_scrape_mentions.csv") if "url_scrape" in self.modules else pd.DataFrame()
        patent_metrics = build_patent_metrics(patent_records)
        citation_metrics = build_citation_metrics(citation_mentions)
        biorxiv_metrics = build_biorxiv_metrics(biorxiv_mentions)
        nih_metrics = build_nih_metrics(nih_mentions)
        url_metrics = build_url_metrics(url_mentions)
        write_edge_case_review_queue([citation_mentions, biorxiv_mentions, nih_mentions, url_mentions], p / "edge_case_review_queue.csv")
        index = build_index(self.companies, patent_metrics, citation_metrics, biorxiv_metrics, nih_metrics, url_metrics, self.config)
        write_csv(index, p / "innovation_index_by_company.csv")
        xlsx_path = p / "innovation_outputs.xlsx"
        try:
            with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
                index.to_excel(writer, sheet_name="innovation_index", index=False)
                for name, df in [("patent_metrics", patent_metrics), ("citation_metrics", citation_metrics), ("biorxiv_metrics", biorxiv_metrics), ("nih_s10_metrics", nih_metrics), ("url_scrape_metrics", url_metrics)]:
                    if not df.empty: df.to_excel(writer, sheet_name=name[:31], index=False)
                sample_map = [("patent_records_sample", patent_records), ("citation_mentions_sample", citation_mentions), ("biorxiv_mentions_sample", biorxiv_mentions), ("nih_s10_sample", nih_mentions), ("url_scrape_sample", url_mentions)]
                for name, df in sample_map:
                    if not df.empty:
                        drop_cols = [c for c in df.columns if c == "raw_record_json" or c.endswith("raw_record_json")]
                        df.drop(columns=drop_cols, errors="ignore").head(5000).to_excel(writer, sheet_name=name[:31], index=False)
                edge_queue = read_csv_if_exists(p / "edge_case_review_queue.csv")
                if not edge_queue.empty:
                    edge_queue.head(10000).to_excel(writer, sheet_name="edge_case_review_queue", index=False)
            self.logger.info("Wrote Excel workbook: %s", xlsx_path)
        except Exception as exc:
            self.logger.warning("Could not write Excel workbook: %s", exc)
        return index

    def run(self) -> None:
        self.write_manifest("started")
        if self.dry_run:
            self.dry_run_plan(); self.write_manifest("dry_run_complete"); return
        self.run_patents()
        self.run_citations()
        self.run_biorxiv()
        self.run_nih_s10()
        self.run_url_scrape()
        index = self.build_outputs()
        self.write_manifest("complete")
        self.logger.info("Complete. Innovation index rows=%d", len(index))

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def load_config(path: Path, args: argparse.Namespace) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    if args.companies:
        config["companies"] = [x.strip().upper() for x in args.companies.split(",") if x.strip()]
    if args.modules:
        config["modules"] = [x.strip().lower() for x in args.modules.split(",") if x.strip()]
    if args.start_year:
        config["start_year"] = int(args.start_year)
    if args.end_year:
        config["end_year"] = int(args.end_year)
    if args.max_records_per_query is not None:
        config["max_records_per_query"] = int(args.max_records_per_query)
    if args.dry_run:
        config["dry_run"] = True
    if args.keep_existing_output:
        config["clean_output"] = False
    return config


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Life-science tools innovation evidence pipeline")
    p.add_argument("--config", default="config.example.yaml")
    p.add_argument("--out", default="outputs/run")
    p.add_argument("--companies", default="")
    p.add_argument("--modules", default="")
    p.add_argument("--start-year", type=int, default=None)
    p.add_argument("--end-year", type=int, default=None)
    p.add_argument("--max-records-per-query", type=int, default=None)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--verbose", action="store_true")
    p.add_argument("--keep-existing-output", action="store_true", help="Do not clear an existing --out folder before running")
    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    base_dir = Path(__file__).resolve().parent
    config = load_config((base_dir / args.config).resolve() if not Path(args.config).is_absolute() else Path(args.config), args)
    pipe = InnovationPipeline(config, base_dir, (base_dir / args.out).resolve() if not Path(args.out).is_absolute() else Path(args.out), verbose=args.verbose)
    pipe.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
