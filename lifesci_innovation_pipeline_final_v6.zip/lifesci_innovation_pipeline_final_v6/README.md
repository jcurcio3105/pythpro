# Life Science Tools Innovation Pipeline - final_v6

This package runs the innovation evidence pipeline using PubMed citations, bioRxiv preprints, NIH S10 awards, and USPTO ODP patent/application data. It is a cleaner package with only the files needed to run plus the dictionaries.

## What changed in final_v6

- Citation search remains PubMed-only by default.
- Removed underspecified, high-false-positive product terms from the active dictionaries, including `heliX`, standalone `JANUS`, `EnVision`, `Bioanalyzer`, `Fragment Analyzer`, `Gen5`, standalone `OpenLab`, `amaZon`, `DataAnalysis`, standalone `WES`, standalone `JESS`, standalone `Octet`, standalone `iQue`, `DAWN`, standalone `Empower`, `UNIFI`, and similar broad terms.
- Kept important company names such as `Waters`, `Fisher`, `Pall`, `Leica`, `Pierce`, `Nunc`, and `Rainin`, but they remain context-required and review-flagged rather than automatically accepted as clean product matches.
- Added redundant hard-blocking of these broad standalone terms in the text matcher so they do not return if accidentally reintroduced.
- Package contents were reduced to the bare minimum needed to run.

## Install

```bash
cd ~/Desktop/lifesci_innovation_pipeline_final_v6
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Credentials

```bash
cp .env.example .env
nano .env
```

Add:

```text
USER_AGENT_EMAIL=your.email@example.com
USPTO_ODP_API_KEY=your_uspto_odp_key_here
```

Optional:

```text
NCBI_API_KEY=your_ncbi_key_here
```

## Dry run

```bash
python innovation_pipeline.py \
  --config config.example.yaml \
  --out outputs/dry_run_final_v6 \
  --companies ILMN,TMO,WAT,TECH \
  --modules patents,citations,biorxiv,nih_s10 \
  --start-year 2022 \
  --end-year 2026 \
  --dry-run \
  --verbose
```

## Full run

```bash
python innovation_pipeline.py \
  --config config.example.yaml \
  --out outputs/full_run_2022_2026_final_v6 \
  --companies TMO,DHR,RVTY,ILMN,A,AVTR,WAT,MTD,TECH,SRT,BRKR \
  --modules patents,citations,biorxiv,nih_s10 \
  --start-year 2022 \
  --end-year 2026 \
  --verbose
```

## Main outputs

```text
outputs/<run_name>/processed/innovation_outputs.xlsx
outputs/<run_name>/processed/innovation_index_by_company.csv
outputs/<run_name>/processed/patent_records_free.csv
outputs/<run_name>/processed/citation_mentions.csv
outputs/<run_name>/processed/biorxiv_mentions.csv
outputs/<run_name>/processed/nih_s10_award_mentions.csv
outputs/<run_name>/processed/edge_case_review_queue.csv
outputs/<run_name>/logs/audit_queries.csv
```

## Dictionary edits

Edit these files and rerun:

```text
dictionaries/company_aliases.csv
dictionaries/product_terms.csv
dictionaries/negative_terms.csv
```


## Final v6 dictionary policy

Final v6 keeps the dictionary holistic while removing underspecified standalone terms that produce high false positives. Specific objective phrases are active, including `EnVision Nexus`, `JANUS G3`, `JANUS BioTx`, `Agilent 2100 Bioanalyzer`, `Agilent Fragment Analyzer`, `BioTek Gen5`, `ProteinSimple Maurice`, `ProteinSimple Jess`, and `ProteinSimple Wes`. Standalone ambiguous/common terms such as `EnVision`, `JANUS`, `Bioanalyzer`, `Fragment Analyzer`, `heliX`, `amaZon`, `WES`, `JESS`, `Octet`, `Empower`, and similar words are not active as standalone PubMed/bioRxiv matches. Core company names such as `Waters`, `Fisher`, `Pall`, `Leica`, and `VWR` remain available as company/alias terms with context requirements and review flags where appropriate.
